﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface;
using Dalamud.Interface.Utility.Raii;
using ccchat.Configuration;
using ccchat.Data.Dto;
using ccchat.Data.Enums;
using ccchat.Data.Models;
using ccchat.Features.Tells;

namespace ccchat.Ui.Windows;

public partial class MainWindow
{
    private void DrawTellsChat()
    {
        var regionWidth = ImGui.GetWindowContentRegionMax().X - ImGui.GetWindowContentRegionMin().X;
        
        var tellsGreen = new Vector4(0.4f, 0.8f, 0.4f, 1.0f);

        if (plugin.TellInterceptor == null)
        {
            // Centered guidance text
            var infoText = "Tells are disabled — enable the module via the button below.";
            var textWidth = ImGui.CalcTextSize(infoText).X;
            var regionWidthInfo = ImGui.GetContentRegionAvail().X;
            var textX = Math.Max(0f, (regionWidthInfo - textWidth) * 0.5f);
            ImGui.SetCursorPosX(textX);
            ImGui.TextColored(new Vector4(0.8f, 0.8f, 0.85f, 1f), infoText);
            ImGui.Spacing();
            
            // Center the enable button
            var availableRegionWidth = ImGui.GetContentRegionAvail().X;
            var buttonWidth = 200f;
            var buttonX = (availableRegionWidth - buttonWidth) * 0.5f;
            ImGui.SetCursorPosX(buttonX);
            
            ImGui.PushStyleColor(ImGuiCol.Button, tellsGreen with { W = 0.9f });
            ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(
                MathF.Min(1f, tellsGreen.X + 0.05f),
                MathF.Min(1f, tellsGreen.Y + 0.1f),
                MathF.Min(1f, tellsGreen.Z + 0.05f),
                0.95f));
            ImGui.PushStyleColor(ImGuiCol.ButtonActive, new Vector4(
                MathF.Max(0f, tellsGreen.X - 0.05f),
                MathF.Max(0f, tellsGreen.Y - 0.1f),
                MathF.Max(0f, tellsGreen.Z - 0.05f),
                1.0f));
            ImGui.PushFont(UiBuilder.IconFont);
            var settingsLabel = FontAwesomeIcon.Comment.ToIconString();
            if (ImGui.Button(settingsLabel, new Vector2(buttonWidth, 30)))
            {
                plugin.ConfigWindow.OpenModulesTab();
                plugin.ToggleConfigUi();
            }
            ImGui.PopFont();
            ImGui.PopStyleColor(3);
            
            return;
        }

        // Get unique senders - only show tabs that user explicitly opened (not auto-opened from history)
        var tellMessages = plugin.TellInterceptor.TellMessages;
        // Build list of open tabs for this session (only user-opened, not auto from history)
        var uniqueSenders = openTellTabs
            .Where(sender => !closedTellTabs.Contains(sender))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        // Ensure current selection is present if still considered open
        if (!string.IsNullOrEmpty(selectedTellTab) &&
            !closedTellTabs.Contains(selectedTellTab) &&
            !uniqueSenders.Contains(selectedTellTab))
        {
            uniqueSenders.Add(selectedTellTab);
        }

        if (!string.IsNullOrWhiteSpace(selectedTellTab))
        {
            EnsureTellPartnerAccountStatus(selectedTellTab);
        }

        var tellPartnerAccountName = !string.IsNullOrEmpty(selectedTellTab)
            ? ResolveTellEchoAccountName(selectedTellTab)
            : null;

        var tellPartnerHasEcho = !string.IsNullOrEmpty(selectedTellTab) &&
            GetTellPartnerAccountStatus(selectedTellTab) == TellPartnerAccountStatus.HasAccount &&
            plugin.ChatService.IsLoggedIn &&
            IsTellPartnerOnline(selectedTellTab);

        var tellPartnerSameDc = !string.IsNullOrEmpty(tellPartnerAccountName)
            ? plugin.GetTellPartnerSameDcStatus(tellPartnerAccountName)
            : null;
        var showCrossDcIndicator = tellPartnerSameDc.HasValue && !tellPartnerSameDc.Value;

        var tellPartnerSameWorld = !string.IsNullOrEmpty(tellPartnerAccountName)
            ? plugin.GetTellPartnerSameWorldStatus(tellPartnerAccountName)
            : null;
        // Show Cross-World indicator when: same DC, different world, and recipient is NOT on friend list
        var showCrossWorldIndicator = !showCrossDcIndicator &&
            tellPartnerSameWorld.HasValue && !tellPartnerSameWorld.Value &&
            tellPartnerHasEcho &&
            !string.IsNullOrEmpty(selectedTellTab) &&
            !IsSelectedTellPartnerOnFriendList(selectedTellTab);

        // Check if either player is in a dungeon
        var localInDungeon = plugin.IsCurrentTerritoryDungeon();
        var recipientWorld = !string.IsNullOrEmpty(tellPartnerAccountName)
            ? plugin.ChatService.GetTellPartnerWorld(tellPartnerAccountName)
            : null;
        if (string.IsNullOrEmpty(recipientWorld) && tellPartnerHasEcho)
        {
            var contact = plugin.ChatService.GetContact(tellPartnerAccountName!);
            recipientWorld = contact?.CurrentWorld;
        }
        var recipientInDungeon = string.Equals(recipientWorld, "Dungeon", StringComparison.OrdinalIgnoreCase);
        var showDungeonIndicator = (localInDungeon || recipientInDungeon) && tellPartnerHasEcho;

        // If dungeon routing is active, suppress cross-DC/world indicators
        if (showDungeonIndicator)
        {
            showCrossDcIndicator = false;
            showCrossWorldIndicator = false;
        }

        // Periodically refresh tell partner's current world while chat is open
        if (tellPartnerHasEcho && !string.IsNullOrEmpty(tellPartnerAccountName))
        {
            plugin.ChatService.RefreshTellPartnerWorldAsync(tellPartnerAccountName);
        }
        var tellPartnerSupportsTyping = tellPartnerHasEcho && !string.IsNullOrWhiteSpace(tellPartnerAccountName);

        // Lodestone ID of the tell partner (for matching pending party requests keyed by lodestoneId)
        var tellPartnerLodestoneId = !string.IsNullOrEmpty(selectedTellTab)
            ? plugin.LodestoneMappingStore?.GetByNameWorld(selectedTellTab)?.LodestoneId
            : null;

        // Prefer resolved Echo mapping; if missing, fall back to lodestone-matched pending request or single pending incoming request
        string? partyTargetAccountName = null;
        var candidateKeys = new List<string?> { tellPartnerAccountName, tellPartnerLodestoneId }
            .Where(k => !string.IsNullOrWhiteSpace(k))
            .ToList();
        partyTargetAccountName = candidateKeys.FirstOrDefault(k =>
            plugin.ChatService.PartyModeActive.ContainsKey(k!) ||
            plugin.ChatService.PartyModePendingIncoming.ContainsKey(k!) ||
            plugin.ChatService.PartyModePendingOutgoing.ContainsKey(k!));

        if (partyTargetAccountName == null && candidateKeys.Count > 0)
        {
            partyTargetAccountName = candidateKeys.First();
        }

        var isTellPartyActive = false;
        var isTellPartyPendingOut = false;
        var isTellPartyPendingIn = false;
        var isTellBoostActive = false;
        var isTellBoostPendingOut = false;
        var isTellBoostPendingIn = false;

        if (string.IsNullOrEmpty(partyTargetAccountName))
        {
            // No explicit mapping found; if exactly one pending incoming request exists, use it as target
            var singlePending = plugin.ChatService.PartyModePendingIncoming.Count == 1
                ? plugin.ChatService.PartyModePendingIncoming.Keys.FirstOrDefault()
                : null;
            if (!string.IsNullOrEmpty(singlePending))
            {
                partyTargetAccountName = singlePending;
            }
        }

        if (!string.IsNullOrEmpty(partyTargetAccountName))
        {
            isTellPartyActive = plugin.ChatService.PartyModeActive.ContainsKey(partyTargetAccountName);
            isTellPartyPendingOut = plugin.ChatService.PartyModePendingOutgoing.ContainsKey(partyTargetAccountName);
            isTellPartyPendingIn = plugin.ChatService.PartyModePendingIncoming.ContainsKey(partyTargetAccountName);

            isTellBoostActive = plugin.ChatService.BoostActive.ContainsKey(partyTargetAccountName);
            isTellBoostPendingOut = plugin.ChatService.BoostPendingOutgoing.ContainsKey(partyTargetAccountName);
            isTellBoostPendingIn = plugin.ChatService.BoostPendingIncoming.ContainsKey(partyTargetAccountName);

            partyMode.IsActive = isTellPartyActive;
            if (isTellBoostActive && !partyMode.IsHardstyleBoost)
                partyMode.ToggleHardstyleBoost();
            else if (!isTellBoostActive && partyMode.IsHardstyleBoost)
                partyMode.ToggleHardstyleBoost();
        }
        else
        {
            if (partyMode.IsActive)
                partyMode.IsActive = false;
            if (partyMode.IsHardstyleBoost)
                partyMode.ToggleHardstyleBoost();
        }

        if (uniqueSenders.Count == 0)
        {
            var avail = ImGui.GetContentRegionAvail();

            var blockHeight = ImGui.GetTextLineHeight() * 4f;
            var offsetY = (avail.Y - blockHeight) * 0.4f;
            if (offsetY > 0) ImGui.Dummy(new Vector2(0, offsetY));

            ImGui.PushFont(UiBuilder.IconFont);
            ImGui.SetWindowFontScale(2.5f);
            var icon = FontAwesomeIcon.Comment.ToIconString();
            var iconSize = ImGui.CalcTextSize(icon);
            ImGui.SetCursorPosX((avail.X - iconSize.X) * 0.5f);
            ImGui.TextColored(new Vector4(0.78f, 0.52f, 1.0f, 0.6f), icon);
            ImGui.SetWindowFontScale(1.0f);
            ImGui.PopFont();

            ImGui.Spacing();

            var primary = "No active chats";
            var primarySize = ImGui.CalcTextSize(primary);
            ImGui.SetCursorPosX((avail.X - primarySize.X) * 0.5f);
            ImGui.TextDisabled(primary);

            var hint = "Use 'Prev. Chats' or search to start a conversation";
            var hintSize = ImGui.CalcTextSize(hint);
            ImGui.SetCursorPosX((avail.X - hintSize.X) * 0.5f);
            ImGui.TextDisabled(hint);

            return;
        }

        var showRegisterCta = !plugin.ChatService.IsLoggedIn;
        var playerHasEchoAccount = plugin.AccountWindow.PlayerHasAccount;

        if (!string.IsNullOrWhiteSpace(selectedTellTab))
        {
            var displayName = selectedTellTab.Contains('@') ? selectedTellTab.Split('@')[0] : selectedTellTab;
            ImGui.AlignTextToFramePadding();
            ImGui.Text(displayName);

            if (!string.IsNullOrEmpty(partyTargetAccountName))
            {
                ImGui.SameLine(0, 6f);

                Vector4 partyBtnColor;
                string partyIcon;
                string partyTooltip;

                if (isTellPartyActive)
                {
                    partyBtnColor = partyMode.GetRgbTextColor();
                    partyIcon = FontAwesomeIcon.Music.ToIconString();
                    partyTooltip = "Stop Party Mode";
                }
                else if (isTellPartyPendingOut)
                {
                    var pulseAlpha = 0.5f + 0.5f * MathF.Sin((float)ImGui.GetTime() * 3f);
                    partyBtnColor = new Vector4(1f, 0.8f, 0.2f, pulseAlpha);
                    partyIcon = FontAwesomeIcon.Spinner.ToIconString();
                    partyTooltip = "Waiting for response... (click to cancel)";
                }
                else
                {
                    partyBtnColor = new Vector4(0.5f, 0.5f, 0.55f, 0.7f);
                    partyIcon = FontAwesomeIcon.Music.ToIconString();
                    partyTooltip = "Start Party Mode";
                }

                ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0, 0, 0, 0));
                ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(0.3f, 0.2f, 0.4f, 0.5f));
                ImGui.PushStyleColor(ImGuiCol.ButtonActive, new Vector4(0.4f, 0.25f, 0.55f, 0.6f));
                ImGui.PushFont(UiBuilder.IconFont);
                ImGui.PushStyleColor(ImGuiCol.Text, partyBtnColor);
                if (ImGui.Button(partyIcon + "##tellPartyToggleHeader", new Vector2(24f, 0)))
                {
                    if (isTellPartyActive)
                    {
                        _ = plugin.ChatService.SendPartyModeStopAsync(partyTargetAccountName);
                        partyMode.Reset();
                    }
                    else if (isTellPartyPendingOut)
                    {
                        _ = plugin.ChatService.SendPartyModeStopAsync(partyTargetAccountName);
                    }
                    else
                    {
                        _ = plugin.ChatService.SendPartyModeRequestAsync(partyTargetAccountName);
                    }
                }
                ImGui.PopStyleColor();
                ImGui.PopFont();
                ImGui.PopStyleColor(3);
                if (ImGui.IsItemHovered())
                {
                    ImGui.SetTooltip(partyTooltip);
                }

                if (isTellPartyActive)
                {
                    ImGui.SameLine(0, 2f);
                    Vector4 boostBtnColor;
                    string boostIcon;
                    string boostTooltip;

                    if (isTellBoostActive)
                    {
                        boostBtnColor = partyMode.GetRgbTextColor(0.33f);
                        boostIcon = FontAwesomeIcon.AngleDoubleUp.ToIconString();
                        boostTooltip = "Level Up";
                    }
                    else if (isTellBoostPendingOut)
                    {
                        var bPulse = 0.5f + 0.5f * MathF.Sin((float)ImGui.GetTime() * 4f);
                        boostBtnColor = new Vector4(1f, 0.4f, 0.1f, bPulse);
                        boostIcon = FontAwesomeIcon.Spinner.ToIconString();
                        boostTooltip = "Level Up";
                    }
                    else
                    {
                        boostBtnColor = new Vector4(1f, 0.6f, 0.1f, 0.7f);
                        boostIcon = FontAwesomeIcon.AngleDoubleUp.ToIconString();
                        boostTooltip = "Level Up";
                    }

                    ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0, 0, 0, 0));
                    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(0.5f, 0.2f, 0.1f, 0.5f));
                    ImGui.PushStyleColor(ImGuiCol.ButtonActive, new Vector4(0.7f, 0.3f, 0.1f, 0.6f));
                    ImGui.PushFont(UiBuilder.IconFont);
                    ImGui.PushStyleColor(ImGuiCol.Text, boostBtnColor);
                    if (ImGui.Button(boostIcon + "##tellHardstyleBoostHeader", new Vector2(24f, 0)))
                    {
                        if (isTellBoostActive)
                        {
                            _ = plugin.ChatService.SendBoostStopAsync(partyTargetAccountName);
                        }
                        else if (isTellBoostPendingOut)
                        {
                            _ = plugin.ChatService.SendBoostStopAsync(partyTargetAccountName);
                        }
                        else
                        {
                            _ = plugin.ChatService.SendBoostRequestAsync(partyTargetAccountName);
                        }
                    }
                    ImGui.PopStyleColor();
                    ImGui.PopFont();
                    ImGui.PopStyleColor(3);
                    if (ImGui.IsItemHovered())
                    {
                        ImGui.SetTooltip(boostTooltip);
                    }
                }
            }

            var status = showRegisterCta
                ? TellPartnerAccountStatus.Unknown
                : GetTellPartnerAccountStatus(selectedTellTab);

            // If a routing indicator (cross-DC / cross-world / dungeon) is shown, hide the Echo wifi icon
            var showAnyRoutingIndicator = showCrossDcIndicator || showCrossWorldIndicator || showDungeonIndicator;
            var showEchoIcon = !showRegisterCta && status == TellPartnerAccountStatus.HasAccount && !showAnyRoutingIndicator;
            var indicatorCursor = ImGui.GetWindowContentRegionMax().X;
            const float indicatorSpacing = 8f;

            if (!showRegisterCta && status != TellPartnerAccountStatus.HasAccount)
            {
                var refreshWidth = 30f;
                var refreshStart = indicatorCursor - refreshWidth;
                indicatorCursor -= refreshWidth + indicatorSpacing;

                ImGui.SameLine(0, 0);
                ImGui.SetCursorPosX(refreshStart);
                ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, 0f);
                ImGui.PushStyleColor(ImGuiCol.Button,        new Vector4(0.18f, 0.16f, 0.24f, 1.0f));
                ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(0.26f, 0.22f, 0.34f, 1.0f));
                ImGui.PushStyleColor(ImGuiCol.ButtonActive,  new Vector4(0.32f, 0.28f, 0.42f, 1.0f));
                ImGui.PushFont(UiBuilder.IconFont);
                if (ImGui.Button(FontAwesomeIcon.SyncAlt.ToIconString() + "##EchoRefreshButton", new Vector2(refreshWidth, ImGui.GetFrameHeight())))
                {
                    ForceRefreshTellPartnerAccountStatus(selectedTellTab);
                }
                ImGui.PopFont();
                ImGui.PopStyleColor(3);
                ImGui.PopStyleVar();
                if (ImGui.IsItemHovered())
                {
                    ImGui.PushFont(UiBuilder.DefaultFont);
                    ImGui.SetTooltip("Re-check Echo availability");
                    ImGui.PopFont();
                }
            }

            if (showEchoIcon)
            {
                var isOnline = IsTellPartnerOnline(selectedTellTab);
                var icon = isOnline ? FontAwesomeIcon.Wifi.ToIconString() : FontAwesomeIcon.Cloud.ToIconString();
                ImGui.PushFont(UiBuilder.IconFont);
                var iconWidth = ImGui.CalcTextSize(icon).X;
                var iconStart = indicatorCursor - iconWidth;
                indicatorCursor -= iconWidth + indicatorSpacing;

                ImGui.SameLine();
                ImGui.SetCursorPosX(iconStart);
                
                if (isOnline)
                {
                    var baseColor = new Vector4(0.2f, 0.9f, 0.3f, 1.0f); // green for online
                    var glowT = (float)ImGui.GetTime() * 0.5f;
                    var wave = 0.5f + 0.5f * MathF.Sin(glowT);
                    var opacity = 0.7f + 0.3f * wave;
                    var glowColor = new Vector4(baseColor.X, baseColor.Y, baseColor.Z, opacity);
                    ImGui.PushStyleColor(ImGuiCol.Text, glowColor);
                    ImGui.Text(icon);
                    ImGui.PopStyleColor();
                }
                else
                {
                    var offlineColor = new Vector4(0.65f, 0.65f, 0.7f, 1.0f);
                    ImGui.PushStyleColor(ImGuiCol.Text, offlineColor);
                    ImGui.Text(icon);
                    ImGui.PopStyleColor();
                }

                ImGui.PopFont();

                if (ImGui.IsItemHovered())
                {
                    ImGui.PushFont(UiBuilder.DefaultFont);
                    ImGui.SetTooltip(isOnline
                        ? "Partner is online (Echo features available)."
                        : "Partner is offline or Echo unavailable.");
                    ImGui.PopFont();
                }

                indicatorCursor = iconStart - indicatorSpacing;
            }

            if (showDungeonIndicator)
            {
                // Green tone for dungeon routing indicator
                var iconColor = new Vector4(0.2f, 0.85f, 0.4f, 0.95f);
                var iconLabel = FontAwesomeIcon.Khanda.ToIconString();
                ImGui.PushFont(UiBuilder.IconFont);
                var iconWidth = ImGui.CalcTextSize(iconLabel).X;
                var iconStart = indicatorCursor - iconWidth;
                indicatorCursor -= iconWidth + indicatorSpacing;
                ImGui.SameLine(0, 0);
                ImGui.SetCursorPosX(iconStart);
                ImGui.PushStyleColor(ImGuiCol.Text, iconColor);
                ImGui.Text(iconLabel);
                ImGui.PopStyleColor();
                ImGui.PopFont();
                if (ImGui.IsItemHovered())
                {
                    ImGui.SetTooltip("Dungeon zone detected; routing via dungeon mode.");
                }
            }

            if (showCrossDcIndicator)
            {
                // Green tone for cross-DC indicator when online, gray when offline
                var isOnline = tellPartnerHasEcho;
                var iconColor = isOnline 
                    ? new Vector4(0.15f, 0.75f, 0.35f, 0.95f)
                    : new Vector4(0.5f, 0.5f, 0.5f, 0.8f);
                var iconLabel = FontAwesomeIcon.GlobeEurope.ToIconString();
                ImGui.PushFont(UiBuilder.IconFont);
                var iconWidth = ImGui.CalcTextSize(iconLabel).X;
                var iconStart = indicatorCursor - iconWidth;
                indicatorCursor -= iconWidth + indicatorSpacing;
                ImGui.SameLine(0, 0);
                ImGui.SetCursorPosX(iconStart);
                ImGui.PushStyleColor(ImGuiCol.Text, iconColor);
                ImGui.Text(iconLabel);
                ImGui.PopStyleColor();
                ImGui.PopFont();
                if (ImGui.IsItemHovered())
                {
                    ImGui.SetTooltip("Different data center detected; cross-DC mode on.");
                }
            }

            if (showCrossWorldIndicator)
            {
                // Green tone for cross-world indicator when online, gray when offline
                var isOnline = tellPartnerHasEcho;
                var iconColor = isOnline 
                    ? new Vector4(0.15f, 0.75f, 0.35f, 0.95f)
                    : new Vector4(0.5f, 0.5f, 0.5f, 0.8f);
                var iconLabel = FontAwesomeIcon.Globe.ToIconString();
                ImGui.PushFont(UiBuilder.IconFont);
                var iconWidth = ImGui.CalcTextSize(iconLabel).X;
                var iconStart = indicatorCursor - iconWidth;
                indicatorCursor -= iconWidth + indicatorSpacing;
                ImGui.SameLine(0, 0);
                ImGui.SetCursorPosX(iconStart);
                ImGui.PushStyleColor(ImGuiCol.Text, iconColor);
                ImGui.Text(iconLabel);
                ImGui.PopStyleColor();
                ImGui.PopFont();
                if (ImGui.IsItemHovered())
                {
                    ImGui.SetTooltip("Different world detected; cross-world mode on.");
                }
            }

            if (showRegisterCta)
            {
                var label = "Activate Echo";
                var labelSize = ImGui.CalcTextSize(label);
                var padding = new Vector2(14f, 6f);
                var buttonWidth = labelSize.X + padding.X * 2;
                var buttonStart = ImGui.GetWindowContentRegionMax().X - buttonWidth;
                ImGui.SameLine(0, 0);
                ImGui.SetCursorPosX(buttonStart);

                var glowT = (float)ImGui.GetTime() * 0.6f;
                var wave = 0.5f + 0.5f * MathF.Sin(glowT);
                var baseColor = new Vector4(0.65f, 0.35f, 0.9f, 1f);
                var hoverColor = new Vector4(0.75f, 0.45f, 1.0f, 1f);
                var activeColor = new Vector4(0.55f, 0.28f, 0.8f, 1f);
                var glowOpacity = 0.25f + 0.2f * wave;

                ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, padding);
                ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, 20f);
                ImGui.PushStyleColor(ImGuiCol.Button, baseColor);
                ImGui.PushStyleColor(ImGuiCol.ButtonHovered, hoverColor);
                ImGui.PushStyleColor(ImGuiCol.ButtonActive, activeColor);

                var buttonPos = ImGui.GetCursorScreenPos();
                var buttonSize = new Vector2(buttonWidth, labelSize.Y + padding.Y * 2);
                var drawList = ImGui.GetWindowDrawList();
                drawList.AddRectFilled(
                    buttonPos - new Vector2(6f, 4f),
                    buttonPos + buttonSize + new Vector2(6f, 4f),
                    ImGui.GetColorU32(new Vector4(baseColor.X, baseColor.Y, baseColor.Z, glowOpacity)),
                    24f);

                if (ImGui.Button(label))
                {
                    var currentDisplayName = plugin.GetPlayerName();
                    if (string.IsNullOrWhiteSpace(currentDisplayName))
                    {
                        currentDisplayName = "CrystalChat Player";
                    }

                    plugin.AccountWindow.SetRegistrationDefaults(
                        plugin.GetPlayerId() ?? currentDisplayName,
                        currentDisplayName,
                        plugin.GetPlayerId() ?? currentDisplayName);
                    plugin.AccountWindow.IsOpen = true;
                    plugin.AccountWindow.StartAutoRegister();
                }
                ImGui.PopStyleColor(3);
                ImGui.PopStyleVar(2);
            }

            var style = ImGui.GetStyle();
            if (!showRegisterCta && status == TellPartnerAccountStatus.Checking)
            {
                var label = "Checking Echo";
                var labelWidth = ImGui.CalcTextSize(label).X;
                var scale = 0.7f;
                var dotsWidth = CalculateTypingDotsWidth(scale);
                var spacing = style.ItemInnerSpacing.X * 0.5f;
                var totalWidth = labelWidth + spacing + dotsWidth;
                var startX = ImGui.GetWindowContentRegionMax().X - totalWidth;
                var indicatorColor = new Vector4(0.65f, 0.75f, 0.85f, 0.9f);

                ImGui.SameLine();
                ImGui.SetCursorPosX(startX);
                ImGui.TextDisabled(label);
                if (ImGui.IsItemHovered())
                {
                    ImGui.SetTooltip("Checking whether this player can use Echo (CCChat account).");
                }
            }
        }

        var showPartyBanner = !string.IsNullOrEmpty(partyTargetAccountName) && isTellPartyPendingIn;
        var showBoostBanner = !string.IsNullOrEmpty(partyTargetAccountName) && isTellBoostPendingIn && isTellPartyActive;

        if (showPartyBanner || showBoostBanner)
        {
            ImGui.Separator();
        }

        if (showPartyBanner && !string.IsNullOrEmpty(partyTargetAccountName))
        {
            ImGui.Spacing();
            var pulseT = (float)ImGui.GetTime();
            var pulseAlpha = 0.15f + 0.1f * MathF.Sin(pulseT * 3f);
            var bannerColor = new Vector4(0.9f, 0.7f, 0.1f, pulseAlpha);
            var bannerMin = ImGui.GetCursorScreenPos();
            var bannerWidth = ImGui.GetContentRegionAvail().X;
            var bannerHeight = ImGui.GetFrameHeightWithSpacing() + 8f;
            var bannerMax = bannerMin + new Vector2(bannerWidth, bannerHeight);
            var drawList = ImGui.GetWindowDrawList();
            drawList.AddRectFilled(bannerMin, bannerMax, ImGui.GetColorU32(bannerColor), 6f);
            drawList.AddRect(bannerMin, bannerMax, ImGui.GetColorU32(new Vector4(1f, 0.8f, 0.2f, 0.5f + 0.3f * MathF.Sin(pulseT * 4f))), 6f, ImDrawFlags.None, 1.5f);

            ImGui.SetCursorScreenPos(bannerMin + new Vector2(8f, 4f));
            ImGui.PushFont(UiBuilder.IconFont);
            ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(1f, 0.8f, 0.2f, 0.7f + 0.3f * MathF.Sin(pulseT * 4f)));
            ImGui.Text(FontAwesomeIcon.Music.ToIconString());
            ImGui.PopStyleColor();
            ImGui.PopFont();
            ImGui.SameLine(0, 6f);
            ImGui.AlignTextToFramePadding();
            ImGui.TextColored(new Vector4(1f, 0.9f, 0.5f, 1f), "Party Mode!");
            ImGui.SameLine(0, 12f);

            ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, new Vector2(12f, 5f));
            ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, 4f);

            ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0.18f, 0.65f, 0.28f, 0.95f));
            ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(0.25f, 0.78f, 0.38f, 1f));
            ImGui.PushStyleColor(ImGuiCol.ButtonActive, new Vector4(0.12f, 0.55f, 0.22f, 1f));
            ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(1f, 1f, 1f, 1f));
            if (ImGui.Button("Join##tellPartyJoin"))
            {
                _ = plugin.ChatService.SendPartyModeAcceptAsync(partyTargetAccountName);
            }
            ImGui.PopStyleColor(4);
            ImGui.SameLine(0, 6f);
            ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0.65f, 0.18f, 0.18f, 0.95f));
            ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(0.78f, 0.28f, 0.28f, 1f));
            ImGui.PushStyleColor(ImGuiCol.ButtonActive, new Vector4(0.55f, 0.12f, 0.12f, 1f));
            ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(1f, 1f, 1f, 1f));
            if (ImGui.Button("Nah##tellPartyNah"))
            {
                _ = plugin.ChatService.SendPartyModeDeclineAsync(partyTargetAccountName);
            }
            ImGui.PopStyleColor(4);

            ImGui.PopStyleVar(2);

            ImGui.SetCursorScreenPos(new Vector2(bannerMin.X, bannerMax.Y + 2f));
            ImGui.Spacing();
        }

        if (showBoostBanner && !string.IsNullOrEmpty(partyTargetAccountName))
        {
            ImGui.Spacing();
            var bPulseT = (float)ImGui.GetTime();
            var bPulseAlpha = 0.15f + 0.12f * MathF.Sin(bPulseT * 5f);
            var bBannerColor = new Vector4(1f, 0.3f, 0.1f, bPulseAlpha);
            var bBannerMin = ImGui.GetCursorScreenPos();
            var bBannerWidth = ImGui.GetContentRegionAvail().X;
            var bBannerHeight = ImGui.GetFrameHeightWithSpacing() + 8f;
            var bBannerMax = bBannerMin + new Vector2(bBannerWidth, bBannerHeight);
            var bDrawList = ImGui.GetWindowDrawList();
            bDrawList.AddRectFilled(bBannerMin, bBannerMax, ImGui.GetColorU32(bBannerColor), 6f);
            bDrawList.AddRect(bBannerMin, bBannerMax, ImGui.GetColorU32(new Vector4(1f, 0.5f, 0.1f, 0.5f + 0.4f * MathF.Sin(bPulseT * 6f))), 6f, ImDrawFlags.None, 1.5f);

            ImGui.SetCursorScreenPos(bBannerMin + new Vector2(8f, 4f));
            ImGui.PushFont(UiBuilder.IconFont);
            ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(1f, 0.5f, 0.1f, 0.7f + 0.3f * MathF.Sin(bPulseT * 6f)));
            ImGui.Text(FontAwesomeIcon.AngleDoubleUp.ToIconString());
            ImGui.PopStyleColor();
            ImGui.PopFont();
            ImGui.SameLine(0, 6f);
            ImGui.AlignTextToFramePadding();
            ImGui.TextColored(new Vector4(1f, 0.7f, 0.3f, 1f), "Level-up +1");
            ImGui.SameLine(0, 12f);

            ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, new Vector2(12f, 5f));
            ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, 4f);

            ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0.7f, 0.25f, 0.05f, 0.95f));
            ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(0.85f, 0.35f, 0.1f, 1f));
            ImGui.PushStyleColor(ImGuiCol.ButtonActive, new Vector4(0.6f, 0.2f, 0.05f, 1f));
            ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(1f, 1f, 1f, 1f));
            if (ImGui.Button("Join##tellBoostJoin"))
            {
                _ = plugin.ChatService.SendBoostAcceptAsync(partyTargetAccountName);
            }
            ImGui.PopStyleColor(4);
            ImGui.SameLine(0, 6f);
            ImGui.PushStyleColor(ImGuiCol.Button, new Vector4(0.4f, 0.15f, 0.15f, 0.95f));
            ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(0.55f, 0.22f, 0.22f, 1f));
            ImGui.PushStyleColor(ImGuiCol.ButtonActive, new Vector4(0.35f, 0.1f, 0.1f, 1f));
            ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(1f, 1f, 1f, 1f));
            if (ImGui.Button("Nah##tellBoostNah"))
            {
                _ = plugin.ChatService.SendBoostDeclineAsync(partyTargetAccountName);
            }
            ImGui.PopStyleColor(4);

            ImGui.PopStyleVar(2);

            ImGui.SetCursorScreenPos(new Vector2(bBannerMin.X, bBannerMax.Y + 2f));
            ImGui.Spacing();
        }

        var tellPartyNow = DateTime.UtcNow;
        var tellPartyDt = (float)(tellPartyNow - lastPartyFrameTime).TotalSeconds;
        lastPartyFrameTime = tellPartyNow;
        partyMode.Update(tellPartyDt);

        // Draw messages for selected tab
        var tellInputHeight = tellPendingAttachment != null ? 54 : 30;
        var typingIndicatorHeight = tellPartnerSupportsTyping ? ImGui.GetFrameHeightWithSpacing() : 0f;
        var chatHeight = ImGui.GetContentRegionAvail().Y - tellInputHeight - typingIndicatorHeight;
        chatHeight = MathF.Max(50f, chatHeight);
        using (ImRaii.Child("TellsMessages", new Vector2(-1, chatHeight), false))
        {
            if (partyMode.IsActive)
            {
                var chatMin = ImGui.GetWindowPos();
                var chatMax = chatMin + ImGui.GetWindowSize();
                partyMode.DrawBackground(chatMin, chatMax);
            }
            var scrollY = ImGui.GetScrollY();
            var scrollMaxY = ImGui.GetScrollMaxY();
            var distanceFromBottom = scrollMaxY - scrollY;
            var atBottom = scrollMaxY <= 0.0f || distanceFromBottom <= 3.0f;
            var atTop = scrollY <= 1.0f;

            if (distanceFromBottom > 30.0f)
            {
                autoScrollToBottom = false;
            }
            if (atBottom)
            {
                autoScrollToBottom = true;
            }

            // Filter messages for selected tab and limit to avoid UI hitches
            List<TellMessage> messagesToRender;
            if (string.IsNullOrEmpty(selectedTellTab))
            {
                messagesToRender = new List<TellMessage>();
            }
            else
            {
                if (!tellMessageLimits.ContainsKey(selectedTellTab))
                {
                    tellMessageLimits[selectedTellTab] = TellMessagesPageSize;
                }

                var senderMessages = tellMessages
                    .Where(m => m.FullSenderName == selectedTellTab)
                    .OrderBy(m => m.Timestamp)
                    .ToList();

                var totalMessages = senderMessages.Count;
                var messageLimit = tellMessageLimits[selectedTellTab];
                var hasOlderMessages = totalMessages > messageLimit;
                if (hasOlderMessages && atTop)
                {
                    var loadIconFont = UiBuilder.IconFont;
                    ImGui.PushFont(loadIconFont);
                    var histIcon = FontAwesomeIcon.History.ToIconString();
                    var histIconSize = ImGui.CalcTextSize(histIcon);
                    ImGui.PopFont();
                    var loadLabel = $"Load {TellMessagesPageSize} older";
                    var loadLabelSize = ImGui.CalcTextSize(loadLabel);
                    var loadIconGap = 4f;
                    var loadBtnPadding = ImGui.GetStyle().FramePadding;
                    var buttonSize = new Vector2(histIconSize.X + loadIconGap + loadLabelSize.X + loadBtnPadding.X * 2, Math.Max(histIconSize.Y, loadLabelSize.Y) + loadBtnPadding.Y * 2);
                    var contentMin = ImGui.GetWindowContentRegionMin();
                    var contentMax = ImGui.GetWindowContentRegionMax();
                    var viewWidth = contentMax.X - contentMin.X;
                    var pos = new Vector2(contentMin.X + (viewWidth - buttonSize.X) * 0.5f, ImGui.GetCursorPosY());
                    var prevCursor = ImGui.GetCursorPos();
                    ImGui.SetCursorPos(pos);
                    var loadBtnScreen = ImGui.GetCursorScreenPos();
                    ImGui.InvisibleButton("##LoadOlderTell", buttonSize);
                    var loadHovered = ImGui.IsItemHovered();
                    var loadActive = ImGui.IsItemActive();
                    var loadClicked = ImGui.IsItemClicked();

                    var loadBg = loadActive
                        ? new Vector4(0.3f, 0.4f, 0.3f, 1.0f)
                        : loadHovered
                            ? new Vector4(0.25f, 0.3f, 0.25f, 0.95f)
                            : new Vector4(0.2f, 0.2f, 0.28f, 0.9f);
                    var loadRounding = buttonSize.Y * 0.5f;
                    var loadDrawList = ImGui.GetWindowDrawList();
                    loadDrawList.AddRectFilled(loadBtnScreen, loadBtnScreen + buttonSize, ImGui.GetColorU32(loadBg), loadRounding);

                    var loadTextColor = ImGui.GetColorU32(new Vector4(1f, 1f, 1f, 1f));
                    var loadIconX = loadBtnScreen.X + loadBtnPadding.X;
                    var loadIconY = loadBtnScreen.Y + (buttonSize.Y - histIconSize.Y) * 0.5f;
                    loadDrawList.AddText(loadIconFont, loadIconFont.FontSize, new Vector2(loadIconX, loadIconY), loadTextColor, histIcon);
                    var loadLabelX = loadIconX + histIconSize.X + loadIconGap;
                    var loadLabelY = loadBtnScreen.Y + (buttonSize.Y - loadLabelSize.Y) * 0.5f;
                    loadDrawList.AddText(new Vector2(loadLabelX, loadLabelY), loadTextColor, loadLabel);

                    if (loadClicked)
                    {
                        messageLimit = Math.Min(totalMessages, messageLimit + TellMessagesPageSize);
                        tellMessageLimits[selectedTellTab] = messageLimit;
                    }
                    ImGui.SetCursorPos(prevCursor);
                    ImGui.Spacing();
                }

                var allowedCount = Math.Min(messageLimit, totalMessages);
                var skipCount = Math.Max(0, totalMessages - allowedCount);
                messagesToRender = senderMessages.Skip(skipCount).ToList();
            }
            
            string? lastTimestamp = null;
            foreach (var msg in messagesToRender)
            {
                lastTimestamp = DrawTellMessage(msg, lastTimestamp);
            }

            var shouldScroll = messagesToRender.Count > 0 && (forceScrollToBottom || (autoScrollToBottom && atBottom));
            if (shouldScroll)
            {
                ImGui.SetScrollHereY(1.0f);
                forceScrollToBottom = false;
            }

            lastScrollY = ImGui.GetScrollY();
        }

        if (tellPartnerSupportsTyping)
        {
            using (ImRaii.Child(
                       "TellsTypingIndicator",
                       new Vector2(-1, typingIndicatorHeight),
                       false,
                       ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoScrollWithMouse))
            {
                if (partyMode.IsActive)
                {
                    var typMin = ImGui.GetWindowPos();
                    var typMax = typMin + ImGui.GetWindowSize();
                    partyMode.DrawBackground(typMin, typMax);
                }
                bool isTyping;
                lock (plugin.ChatService.DataLock)
                {
                    isTyping = plugin.ChatService.TypingIndicators
                        .GetValueOrDefault(tellPartnerAccountName!);
                }

                if (isTyping)
                {
                    var indicatorColor = new Vector4(0.65f, 0.75f, 0.85f, 0.9f);
                    ImGui.PushStyleColor(ImGuiCol.Text, indicatorColor);
                    var displayName = selectedTellTab!.Contains('@')
                        ? selectedTellTab.Split('@')[0]
                        : selectedTellTab;
                    ImGui.TextDisabled($"{displayName} is typing");
                    ImGui.SameLine(0, ImGui.GetStyle().ItemInnerSpacing.X * 1.2f);
                    DrawTypingWaveDots(indicatorColor, $"tell_typing_{tellPartnerAccountName}");
                    ImGui.PopStyleColor();
                }
            }
        }

        // Input field for sending tells
        if (!string.IsNullOrEmpty(selectedTellTab))
        {
            ImGui.Separator();

            // Draw pending tell attachment bar
            if (tellPendingAttachment != null)
            {
                DrawTellPendingAttachment();
            }

            // Fixed layout constants â€“ never change regardless of Echo state
            const float reservedEchoBlock = 120f; // 3 x 40px (+, emoji, gif slots)
            const float actionBtnWidth    = 40f; // requested width
            const float emojiBtnWidth     = 40f;
            const float gifBtnWidth       = 40f;
            const float sendBtnWidth      = 40f; // same width as other buttons
            var shareButtonActive = !tellPartnerHasEcho;
            var shareSlotWidth    = shareButtonActive ? 36f : 6f; // small spacer when echo on
            // set small horizontal spacing (2px) for this row
            var rowStyle = ImGui.GetStyle();
            const float itemSpacing = 2f;
            ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing, new Vector2(itemSpacing, rowStyle.ItemSpacing.Y));
            // inputWidth accounts for spacing between: plus/share, share/input, input/emoji, emoji/gif, gif/send, send/padding
            var inputWidth = ImGui.GetContentRegionAvail().X - sendBtnWidth - shareSlotWidth - reservedEchoBlock - itemSpacing * 6f - 2f;
            inputWidth = MathF.Max(50f, inputWidth);
            // Fixed row height via FramePadding
            const float rowHeight = 24f;
            ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, new Vector2(4f, (rowHeight - ImGui.GetFontSize()) * 0.5f));

            // Echo action button (+) for attachments/GIFs
            if (tellPartnerHasEcho)
            {
                // slot 1: + button
                using (ImRaii.Disabled(isUploadingTellAttachment))
                {
                    // Metro: flat lila with manually centered icon
                    ImGui.PushStyleColor(ImGuiCol.Button,        new Vector4(0.22f, 0.18f, 0.32f, 1.0f));
                    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(0.30f, 0.24f, 0.44f, 1.0f));
                    ImGui.PushStyleColor(ImGuiCol.ButtonActive,  new Vector4(0.38f, 0.30f, 0.56f, 1.0f));
                    ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, 0f);
                    ImGui.PushFont(UiBuilder.IconFont);
                    var plusLabel = FontAwesomeIcon.Plus.ToIconString();
                    var plusSize = ImGui.CalcTextSize(plusLabel);
                    var plusClicked = ImGui.InvisibleButton("##TellAction", new Vector2(actionBtnWidth, rowHeight));
                    var plusDl = ImGui.GetWindowDrawList();
                    var plusMin = ImGui.GetItemRectMin();
                    var plusMax = ImGui.GetItemRectMax();
                    var plusBase = new Vector4(0.22f, 0.18f, 0.32f, 1.0f);
                    var plusHover = new Vector4(0.30f, 0.24f, 0.44f, 1.0f);
                    var plusActive = new Vector4(0.38f, 0.30f, 0.56f, 1.0f);
                    var plusColor = ImGui.IsItemActive() ? plusActive : ImGui.IsItemHovered() ? plusHover : plusBase;
                    plusDl.AddRectFilled(plusMin, plusMax, ImGui.GetColorU32(plusColor));
                    var plusPos = new Vector2(
                        MathF.Round(plusMin.X + (actionBtnWidth - plusSize.X) * 0.5f),
                        MathF.Round(plusMin.Y + (rowHeight - plusSize.Y) * 0.5f));
                    plusDl.AddText(UiBuilder.IconFont, UiBuilder.IconFont.FontSize, plusPos, ImGui.GetColorU32(new Vector4(1f, 1f, 1f, 1f)), plusLabel);
                    if (plusClicked)
                    {
                        ImGui.OpenPopup("TellActionMenu");
                    }
                    ImGui.PopFont();
                    ImGui.PopStyleColor(3);
                    ImGui.PopStyleVar();
                }
                if (ImGui.IsItemHovered(ImGuiHoveredFlags.AllowWhenDisabled))
                {
                    ImGui.SetTooltip("Attachments and GIFs (via Echo)");
                }

                ImGui.SetNextWindowSize(new Vector2(220f, 0f), ImGuiCond.Appearing);

                // Open the action menu above the + button (anchor bottom-left of popup to top-left of button)
                var actionBtnMin = ImGui.GetItemRectMin();
                var menuPos = new Vector2(actionBtnMin.X, actionBtnMin.Y - 4f);
                ImGui.SetNextWindowPos(menuPos, ImGuiCond.Appearing, new Vector2(0f, 1f));

                if (ImGui.BeginPopup("TellActionMenu"))
                {
                    DrawAccountMenuItem(
                        "##TellAttach",
                        "Attach file (images)",
                        FontAwesomeIcon.Paperclip,
                        new Vector4(0.80f, 0.70f, 0.95f, 1.0f),
                        new Vector4(0.95f, 0.95f, 0.98f, 1.0f),
                        () => _ = OpenTellFileDialogAsync());

                    ImGui.Dummy(new Vector2(0f, 4f));
                    DrawAccountMenuItem(
                        "##TellPaste",
                        "Paste from clipboard",
                        FontAwesomeIcon.Clipboard,
                        new Vector4(0.80f, 0.70f, 0.95f, 1.0f),
                        new Vector4(0.95f, 0.95f, 0.98f, 1.0f),
                        () => _ = PasteTellFromClipboardAsync());

                    ImGui.EndPopup();
                }

                ImGui.SameLine();
            }
            else
            {
                // slot 1+2 placeholder when Echo is off (same total width as 2 echo buttons)
                ImGui.Dummy(new Vector2(reservedEchoBlock, rowHeight));
                ImGui.SameLine();
            }

            // Share button slot (always same width; invisible when Echo is on)
            if (shareButtonActive)
            {
                // Metro: flat lila share button
                ImGui.PushStyleColor(ImGuiCol.Button,        new Vector4(0.22f, 0.18f, 0.32f, 1.0f));
                ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(0.30f, 0.24f, 0.44f, 1.0f));
                ImGui.PushStyleColor(ImGuiCol.ButtonActive,  new Vector4(0.38f, 0.30f, 0.56f, 1.0f));
                ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(0.80f, 0.70f, 0.95f, 1.0f));
                ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, 0f);
                ImGui.PushFont(UiBuilder.IconFont);
                var shareLabel = FontAwesomeIcon.Share.ToIconString();
                var shareSize = ImGui.CalcTextSize(shareLabel);
                var shareClicked = ImGui.InvisibleButton("##TellShare", new Vector2(shareSlotWidth, rowHeight));
                var shareDl = ImGui.GetWindowDrawList();
                var shareMin = ImGui.GetItemRectMin();
                var shareMax = ImGui.GetItemRectMax();
                var shareBase = new Vector4(0.22f, 0.18f, 0.32f, 1.0f);
                var shareHover = new Vector4(0.30f, 0.24f, 0.44f, 1.0f);
                var shareActive = new Vector4(0.38f, 0.30f, 0.56f, 1.0f);
                var shareColor = ImGui.IsItemActive() ? shareActive : ImGui.IsItemHovered() ? shareHover : shareBase;
                shareDl.AddRectFilled(shareMin, shareMax, ImGui.GetColorU32(shareColor));
                var sharePos = new Vector2(
                    MathF.Round(shareMin.X + (shareSlotWidth - shareSize.X) * 0.5f),
                    MathF.Round(shareMin.Y + (rowHeight - shareSize.Y) * 0.5f));
                shareDl.AddText(UiBuilder.IconFont, UiBuilder.IconFont.FontSize, sharePos, ImGui.GetColorU32(new Vector4(1f, 1f, 1f, 1f)), shareLabel);
                if (shareClicked)
                {
                    const string shareUrl = "https://raw.githubusercontent.com/verrilmerteuil/cc-repo/refs/heads/main/pluginmaster.json ";
                    tellMessageInput = shareUrl;
                    focusTellMessageInput = true;
                }
                ImGui.PopFont();
                if (ImGui.IsItemHovered())
                {
                    ImGui.PushFont(UiBuilder.DefaultFont);
                    ImGui.SetTooltip("Share repository link\nCopies the plugin master JSON URL");
                    ImGui.PopFont();
                }
                ImGui.PopStyleColor(4);
                ImGui.PopStyleVar();
            }
            else
            {
                // Echo is on: share slot is small spacer
                ImGui.Dummy(new Vector2(shareSlotWidth, rowHeight));
            }
            ImGui.SameLine();

            ImGui.SetNextItemWidth(inputWidth);
            ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, 0f);
            ImGui.PushStyleVar(ImGuiStyleVar.FrameBorderSize, 1f);
            ImGui.PushStyleColor(ImGuiCol.FrameBg,        new Vector4(0.08f, 0.08f, 0.10f, 1.0f));
            ImGui.PushStyleColor(ImGuiCol.FrameBgHovered, new Vector4(0.12f, 0.12f, 0.16f, 1.0f));
            ImGui.PushStyleColor(ImGuiCol.FrameBgActive,  new Vector4(0.18f, 0.14f, 0.30f, 1.0f));
            ImGui.PushStyleColor(ImGuiCol.Border,         new Vector4(0.35f, 0.28f, 0.52f, 1.0f));
            var inputStartPos = ImGui.GetCursorPos();
            if (focusTellMessageInput)
            {
                ImGui.SetKeyboardFocusHere();
                focusTellMessageInput = false;
            }
            var enterPressed = ImGui.InputTextWithHint("##TellMessageInput", "Type a message...", ref tellMessageInput, MaxMessageLength, ImGuiInputTextFlags.EnterReturnsTrue);
            ImGui.PopStyleColor(4);
            ImGui.PopStyleVar(3); // FramePadding, Rounding, BorderSize

            if (tellPartnerSupportsTyping && ImGui.IsItemActive() && tellMessageInput.Length > 0)
            {
                var now = DateTime.UtcNow;
                var changedSinceLastSend = !string.Equals(lastTypingSnapshot, tellMessageInput, StringComparison.Ordinal);
                if (changedSinceLastSend && (now - lastTypingSentAt).TotalMilliseconds >= TypingSendCooldownMs)
                {
                    lastTypingSentAt = now;
                    lastTypingSnapshot = tellMessageInput;
                    _ = plugin.ChatService.SendTypingAsync(tellPartnerAccountName!);
                }
            }

            // Echo emoji button
            if (tellPartnerHasEcho)
            {
                ImGui.SameLine();
                using (ImRaii.Disabled(isUploadingTellAttachment))
                {
                    // Metro: flat lila emoji button, custom drawn to center icon
                    ImGui.PushStyleColor(ImGuiCol.Button,        new Vector4(0.22f, 0.18f, 0.32f, 1.0f));
                    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(0.30f, 0.24f, 0.44f, 1.0f));
                    ImGui.PushStyleColor(ImGuiCol.ButtonActive,  new Vector4(0.38f, 0.30f, 0.56f, 1.0f));
                    ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, 0f);
                    ImGui.PushFont(UiBuilder.IconFont);
                    var emojiLabel = FontAwesomeIcon.SmileBeam.ToIconString();
                    var emojiSize = ImGui.CalcTextSize(emojiLabel); // measured with icon font active
                    var emojiClicked = ImGui.InvisibleButton("##TellEmoji", new Vector2(emojiBtnWidth, rowHeight));
                    var emojiDraw = ImGui.GetWindowDrawList();
                    var emojiMin = ImGui.GetItemRectMin();
                    var emojiMax = ImGui.GetItemRectMax();
                    var emojiBase = new Vector4(0.22f, 0.18f, 0.32f, 1.0f);
                    var emojiHover = new Vector4(0.30f, 0.24f, 0.44f, 1.0f);
                    var emojiActive = new Vector4(0.38f, 0.30f, 0.56f, 1.0f);
                    var emojiColor = ImGui.IsItemActive() ? emojiActive : ImGui.IsItemHovered() ? emojiHover : emojiBase;
                    emojiDraw.AddRectFilled(emojiMin, emojiMax, ImGui.GetColorU32(emojiColor));
                    var emojiPos = new Vector2(
                        MathF.Round(emojiMin.X + (emojiBtnWidth - emojiSize.X) * 0.5f),
                        MathF.Round(emojiMin.Y + (rowHeight - emojiSize.Y) * 0.5f));
                    emojiDraw.AddText(UiBuilder.IconFont, UiBuilder.IconFont.FontSize, emojiPos, ImGui.GetColorU32(new Vector4(1f, 1f, 1f, 1f)), emojiLabel);
                    if (emojiClicked)
                    {
                        plugin.UnifiedPickerWindow.Open(UnifiedPickerWindow.PickerTab.Emoji);
                    }
                    ImGui.PopFont();
                    ImGui.PopStyleColor(3);
                    ImGui.PopStyleVar();
                }
                if (ImGui.IsItemHovered())
                {
                    ImGui.SetTooltip("Emoji picker");
                }

                // GIF button (Echo)
                ImGui.SameLine();
                using (ImRaii.Disabled(isUploadingTellAttachment))
                {
                    ImGui.PushStyleColor(ImGuiCol.Button,        new Vector4(0.22f, 0.18f, 0.32f, 1.0f));
                    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(0.30f, 0.24f, 0.44f, 1.0f));
                    ImGui.PushStyleColor(ImGuiCol.ButtonActive,  new Vector4(0.38f, 0.30f, 0.56f, 1.0f));
                    ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, 0f);
                    ImGui.PushFont(UiBuilder.IconFont);
                    var gifLabel = FontAwesomeIcon.Images.ToIconString();
                    var gifSize = ImGui.CalcTextSize(gifLabel);
                    var gifClicked = ImGui.InvisibleButton("##TellGifBtn", new Vector2(gifBtnWidth, rowHeight));
                    var gifDraw = ImGui.GetWindowDrawList();
                    var gifMin = ImGui.GetItemRectMin();
                    var gifMax = ImGui.GetItemRectMax();
                    var gifBase = new Vector4(0.22f, 0.18f, 0.32f, 1.0f);
                    var gifHover = new Vector4(0.30f, 0.24f, 0.44f, 1.0f);
                    var gifActive = new Vector4(0.38f, 0.30f, 0.56f, 1.0f);
                    var gifColor = ImGui.IsItemActive() ? gifActive : ImGui.IsItemHovered() ? gifHover : gifBase;
                    gifDraw.AddRectFilled(gifMin, gifMax, ImGui.GetColorU32(gifColor));
                    var gifPos = new Vector2(
                        MathF.Round(gifMin.X + (gifBtnWidth - gifSize.X) * 0.5f),
                        MathF.Round(gifMin.Y + (rowHeight - gifSize.Y) * 0.5f));
                    gifDraw.AddText(UiBuilder.IconFont, UiBuilder.IconFont.FontSize, gifPos, ImGui.GetColorU32(new Vector4(1f, 1f, 1f, 1.0f)), gifLabel);
                    if (gifClicked)
                    {
                        plugin.UnifiedPickerWindow.Open(UnifiedPickerWindow.PickerTab.Gif);
                    }
                    ImGui.PopFont();
                    ImGui.PopStyleColor(3);
                    ImGui.PopStyleVar();
                }
                if (ImGui.IsItemHovered())
                {
                    ImGui.SetTooltip("GIF picker");
                }
            }

            ImGui.SameLine();
            var canSend = !string.IsNullOrWhiteSpace(tellMessageInput) || tellPendingAttachment != null;
            // Metro: flat lila send button, brighter when active
            using (ImRaii.Disabled(!canSend))
            {
                ImGui.PushStyleColor(ImGuiCol.Button,        canSend ? new Vector4(0.38f, 0.28f, 0.62f, 1.0f) : new Vector4(0.18f, 0.15f, 0.26f, 1.0f));
                ImGui.PushStyleColor(ImGuiCol.ButtonHovered, new Vector4(0.48f, 0.36f, 0.78f, 1.0f));
                ImGui.PushStyleColor(ImGuiCol.ButtonActive,  new Vector4(0.55f, 0.42f, 0.88f, 1.0f));
                ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, 0f);
                ImGui.PushFont(UiBuilder.IconFont);
                var sendLabel = FontAwesomeIcon.PaperPlane.ToIconString();
                var iconFont = UiBuilder.IconFont;
                var iconFontSize = iconFont.FontSize;
                var iconSize = ImGui.CalcTextSize(sendLabel); // measured with icon font active
                // Use InvisibleButton for custom drawing to center icon
                var clicked = ImGui.InvisibleButton("##TellSendBtn", new Vector2(sendBtnWidth, rowHeight));
                var dl = ImGui.GetWindowDrawList();
                var btnMin = ImGui.GetItemRectMin();
                var btnMax = ImGui.GetItemRectMax();
                var btnColor = canSend ? new Vector4(0.38f, 0.28f, 0.62f, 1.0f) : new Vector4(0.18f, 0.15f, 0.26f, 1.0f);
                var hoverColor = new Vector4(0.48f, 0.36f, 0.78f, 1.0f);
                var activeColor = new Vector4(0.55f, 0.42f, 0.88f, 1.0f);
                var finalColor = ImGui.IsItemActive() ? activeColor : ImGui.IsItemHovered() ? hoverColor : btnColor;
                dl.AddRectFilled(btnMin, btnMax, ImGui.GetColorU32(finalColor));
                var iconDrawPos = new Vector2(
                    MathF.Round(btnMin.X + (sendBtnWidth - iconSize.X) * 0.5f),
                    MathF.Round(btnMin.Y + (rowHeight - iconSize.Y) * 0.5f));
                dl.AddText(iconFont, iconFontSize, iconDrawPos, ImGui.GetColorU32(new Vector4(1f, 1f, 1f, 1f)), sendLabel);
                if ((clicked || enterPressed) && canSend)
                {
                    if (tellPendingAttachment != null)
                    {
                        SendTellEchoAttachment();
                    }
                    else
                    {
                        SendTellMessage();
                    }
                }
                ImGui.PopFont();
                ImGui.PopStyleColor(3);
                ImGui.PopStyleVar();
            }

            // small right padding so the send button is not clipped by the container edge
            ImGui.SameLine();
            ImGui.Dummy(new Vector2(6f, rowHeight));

            var style = ImGui.GetStyle();
            var barHeight = 3f;
            var fullBarWidth = ImGui.GetContentRegionAvail().X - 2f;
            var barPos = new Vector2(0f, inputStartPos.Y + ImGui.GetFrameHeight() + 2f);
            ImGui.SetCursorPos(barPos);
            var usageRatio = MathF.Min(1f, (float)tellMessageInput.Length / MaxMessageLength);
            // Metro: lila char-counter bar, red near limit
            var barColor = usageRatio > 0.9f
                ? new Vector4(0.75f, 0.20f, 0.25f, 0.95f)
                : usageRatio > 0.7f
                    ? new Vector4(0.60f, 0.35f, 0.75f, 0.9f)
                    : new Vector4(0.38f, 0.28f, 0.62f, 0.85f);
            ImGui.PushStyleColor(ImGuiCol.FrameBg, new Vector4(0.12f, 0.10f, 0.18f, 0.7f));
            ImGui.PushStyleColor(ImGuiCol.PlotHistogram, barColor);
            ImGui.ProgressBar(usageRatio, new Vector2(fullBarWidth, barHeight), string.Empty);
            ImGui.PopStyleColor(2);
            ImGui.Dummy(new Vector2(0f, barHeight + style.ItemSpacing.Y));
            // restore ItemSpacing for following rows
            ImGui.PopStyleVar();
        }
        else
        {
            ImGui.TextDisabled("Select a contact tab to send tells.");
        }
        
        // Save open tabs to configuration
        SaveOpenTellTabs();
        SaveUnreadTellTabs();
    }

    private void SaveOpenTellTabs()
    {
        if (plugin.TellInterceptor == null) return;
        
        var openTabs = openTellTabs
            .Where(sender => !closedTellTabs.Contains(sender))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
            .ToList();

        // Avoid writing config if nothing changed to prevent excessive disk writes and potential permission errors
        if (lastSavedOpenTellTabs.SequenceEqual(openTabs, StringComparer.OrdinalIgnoreCase))
        {
            return;
        }

        lastSavedOpenTellTabs = new List<string>(openTabs);

        plugin.Configuration.OpenTellTabs = openTabs;
        plugin.Configuration.Save();
    }

    private void SaveUnreadTellTabs()
    {
        if (plugin.TellInterceptor == null) return;

        var unreadTabs = tellTabUnreadCounts
            .Where(kvp => kvp.Value > 0)
            .Select(kvp => kvp.Key)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (lastSavedUnreadTellTabs.SequenceEqual(unreadTabs, StringComparer.OrdinalIgnoreCase))
        {
            return;
        }

        lastSavedUnreadTellTabs = new List<string>(unreadTabs);

        plugin.Configuration.UnreadTellTabs = unreadTabs;
        plugin.Configuration.Save();
    }

    private void ClearTellUnread(string sender)
    {
        if (string.IsNullOrWhiteSpace(sender))
        {
            return;
        }

        var previous = tellTabUnreadCounts.GetValueOrDefault(sender, 0);
        if (previous > 0)
        {
            tellsUnreadCount = Math.Max(0, tellsUnreadCount - previous);
        }

        tellTabUnreadCounts[sender] = 0;
        SaveUnreadTellTabs();
    }

    private void SetupRegistrationDefaults()
    {
        // If the user already set registration defaults in the past (legacy flow), keep their choice
        if (!string.IsNullOrEmpty(plugin.Configuration.RegisteredAccountName))
        {
            plugin.AccountWindow.SetRegistrationDefaults(
                plugin.Configuration.RegisteredAccountName,
                plugin.Configuration.RegisteredCharacterName ?? plugin.Configuration.RegisteredAccountName,
                plugin.Configuration.RegisteredAccountName);
            return;
        }

        var playerId = plugin.GetPlayerId();
        if (string.IsNullOrEmpty(playerId))
        {
            Plugin.Log.Warning("Cannot prefill registration defaults without player ID");
            return;
        }

        var displayName = plugin.GetPlayerName();
        if (string.IsNullOrWhiteSpace(displayName))
        {
            displayName = "CrystalChat Player";
        }

        plugin.AccountWindow.SetRegistrationDefaults(playerId, displayName, playerId);
    }

    public List<string> GetOpenTellTabs()
    {
        return openTellTabs
            .Where(sender => !closedTellTabs.Contains(sender))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    public void FocusTellTabFromWeb(string tab)
    {
        if (string.IsNullOrWhiteSpace(tab)) return;
        FocusTellChat(tab);
    }

    public void CloseTellTabFromWeb(string tab)
    {
        if (string.IsNullOrWhiteSpace(tab))
        {
            return;
        }

        CloseTellTab(tab);
        SaveOpenTellTabs();
    }

    private void SendTellMessage()
    {
        if (string.IsNullOrEmpty(selectedTellTab) || string.IsNullOrWhiteSpace(tellMessageInput))
        {
            return;
        }

        var recipient = selectedTellTab;
        var message = tellMessageInput.Trim();

        if (plugin.Configuration.EnableCommandPassthrough &&
            !string.IsNullOrWhiteSpace(message) &&
            message.StartsWith("/"))
        {
            plugin.ExecuteGameCommand(message);
            tellMessageInput = string.Empty;
            focusTellMessageInput = true;
            return;
        }
        
        plugin.SendTell(recipient, message);
        
        tellMessageInput = string.Empty;
        focusTellMessageInput = true;
    }

    private void DrawTellPendingAttachment()
    {
        ImGui.PushStyleColor(ImGuiCol.ChildBg, new Vector4(0.2f, 0.2f, 0.3f, 0.5f));
        using (ImRaii.Child("TellPendingAttachment", new Vector2(-1, 24), false))
        {
            var isImage = tellPendingAttachment!.Mime?.StartsWith("image", StringComparison.OrdinalIgnoreCase) == true;
            var icon = isImage ? FontAwesomeIcon.Image.ToIconString() : FontAwesomeIcon.Paperclip.ToIconString();

            ImGui.PushFont(UiBuilder.IconFont);
            ImGui.Text(icon);
            ImGui.PopFont();

            ImGui.SameLine(0, ImGui.GetStyle().ItemInnerSpacing.X);
            ImGui.Text($"{tellPendingAttachment.Filename} ({FormatBytes(tellPendingAttachment.Size)})");

            ImGui.SameLine();
            var removeX = ImGui.GetContentRegionAvail().X;
            var buttonSize = new Vector2(22, ImGui.GetFrameHeight());
            ImGui.SetCursorPosX(ImGui.GetCursorPosX() + removeX - buttonSize.X);

            ImGui.PushFont(UiBuilder.IconFont);
            if (ImGui.Button(FontAwesomeIcon.Times.ToIconString() + "##RemoveTellAttachment", buttonSize))
            {
                tellPendingAttachment = null;
            }
            ImGui.PopFont();

            if (ImGui.IsItemHovered())
            {
                ImGui.SetTooltip("Discard attachment");
            }
        }
        ImGui.PopStyleColor();
    }

    private async Task OpenTellFileDialogAsync()
    {
        isUploadingTellAttachment = true;
        try
        {
            var filePath = await ShowFileDialogAsync(
                "Select file to attach",
                "Images|*.png;*.jpg;*.jpeg;*.gif;*.webp;*.bmp|All files|*.*");

            if (string.IsNullOrWhiteSpace(filePath)) return;

            var fileData = await Task.Run(() => System.IO.File.ReadAllBytes(filePath));
            if (fileData.Length > MaxAttachmentSize)
            {
                errorMessage = "File too large (max 7 MB).";
                return;
            }

            var filename = System.IO.Path.GetFileName(filePath);
            var mimeType = GetMimeType(filePath);
            var (result, error) = await plugin.ChatService.UploadAttachmentAsync(fileData, filename, mimeType);

            if (result != null)
            {
                tellPendingAttachment = result;
            }
            else
            {
                errorMessage = $"Upload failed: {error}";
            }
        }
        catch (Exception ex)
        {
            Plugin.Log.Error($"Tell file upload error: {ex.Message}");
        }
        finally
        {
            isUploadingTellAttachment = false;
        }
    }

    private async Task PasteTellFromClipboardAsync()
    {
        isUploadingTellAttachment = true;
        try
        {
            var clipboard = await ReadClipboardAsync();
            var clipboardData = clipboard.ImageBytes;

            if (clipboardData == null || clipboardData.Length == 0)
            {
                errorMessage = "No image in clipboard.";
                return;
            }

            if (clipboardData.Length > MaxAttachmentSize)
            {
                errorMessage = "Clipboard image too large (max 7 MB).";
                return;
            }

            var filename = clipboard.Filename ?? $"clipboard_{DateTime.Now:yyyyMMdd_HHmmss}.png";
            var mimeType = clipboard.ImageMime ?? "image/png";
            var (result, error) = await plugin.ChatService.UploadAttachmentAsync(clipboardData, filename, mimeType);

            if (result != null)
            {
                tellPendingAttachment = result;
            }
            else
            {
                errorMessage = $"Upload failed: {error}";
            }
        }
        catch (Exception ex)
        {
            Plugin.Log.Error($"Tell clipboard paste error: {ex.Message}");
        }
        finally
        {
            isUploadingTellAttachment = false;
        }
    }

    private void SendTellEchoAttachment()
    {
        if (string.IsNullOrEmpty(selectedTellTab) || tellPendingAttachment == null)
            return;

        var accountName = ResolveTellEchoAccountName(selectedTellTab);
        if (string.IsNullOrEmpty(accountName))
        {
            errorMessage = "Cannot resolve Echo account for this tell partner.";
            tellPendingAttachment = null;
            return;
        }

        var body = string.IsNullOrWhiteSpace(tellMessageInput) ? null : tellMessageInput;
        var attachmentId = tellPendingAttachment.AttachmentId;
        var attachmentInfo = new ccchat.Data.Models.AttachmentInfo
        {
            Id = tellPendingAttachment.AttachmentId,
            Filename = tellPendingAttachment.Filename,
            Mime = tellPendingAttachment.Mime,
            Size = tellPendingAttachment.Size
        };

        // Send via WebSocket DM
        _ = plugin.ChatService.SendMessageAsync(accountName, body, attachmentId, attachmentInfo);

        // Inject Echo message into tell history
        var isGif = tellPendingAttachment.Mime?.Equals("image/gif", StringComparison.OrdinalIgnoreCase) == true;
        var parts = selectedTellTab.Split('@');
        var echoMsg = new TellMessage
        {
            SenderName = parts.Length > 0 ? parts[0] : selectedTellTab,
            SenderWorld = parts.Length > 1 ? parts[1] : string.Empty,
            Message = body ?? string.Empty,
            Timestamp = DateTime.UtcNow,
            IsIncoming = false,
            EchoType = isGif ? TellEchoType.Gif : TellEchoType.Attach,
            EchoAttachmentId = tellPendingAttachment.AttachmentId,
            EchoFilename = tellPendingAttachment.Filename,
            EchoMime = tellPendingAttachment.Mime,
            EchoSize = tellPendingAttachment.Size
        };
        plugin.TellInterceptor?.InjectEchoMessage(echoMsg);

        tellMessageInput = string.Empty;
        tellPendingAttachment = null;
        focusTellMessageInput = true;
        forceScrollToBottom = true;
    }

    public void SendTellGifAttachment(ccchat.Data.Dto.AttachmentUploadResponse attachment)
    {
        if (showTellsChat && !string.IsNullOrEmpty(selectedTellTab))
        {
            var accountName = ResolveTellEchoAccountName(selectedTellTab);
            if (!string.IsNullOrEmpty(accountName))
            {
                tellPendingAttachment = attachment;
                SendTellEchoAttachment();
                return;
            }
        }

        // Fallback to contacts chat
        pendingAttachment = attachment;
        SendMessageWithAttachment();
    }

    public void SendTellGifUrl(string url)
    {
        if (!showTellsChat || string.IsNullOrEmpty(selectedTellTab) || string.IsNullOrWhiteSpace(url))
            return;

        var accountName = ResolveTellEchoAccountName(selectedTellTab);
        if (string.IsNullOrEmpty(accountName))
            return;

        var body = url;

        // Send via WebSocket DM (fire-and-forget)
        _ = plugin.ChatService.SendMessageAsync(accountName, body, null, null);

        // Inject Echo message into tell history
        var parts = selectedTellTab.Split('@');
        var echoMsg = new TellMessage
        {
            SenderName = parts.Length > 0 ? parts[0] : selectedTellTab,
            SenderWorld = parts.Length > 1 ? parts[1] : string.Empty,
            Message = body,
            Timestamp = DateTime.UtcNow,
            IsIncoming = false,
            EchoType = TellEchoType.GifUrl,
            EchoData = url
        };
        plugin.TellInterceptor?.InjectEchoMessage(echoMsg);

        tellMessageInput = string.Empty;
        focusTellMessageInput = true;
    }

    public void SendGroupGifUrl(string url)
    {
        if (!showGroupsPanel || selectedGroupId == null || string.IsNullOrWhiteSpace(url))
            return;

        var body = url;

        // Send via WebSocket group message (fire-and-forget)
        _ = plugin.ChatService.SendGroupMessageAsync(selectedGroupId.Value, body, null);

        messageInput = string.Empty;
        focusMessageInput = true;
        forceScrollToBottom = true;
    }

    private string? ResolveTellEchoAccountName(string nameAtWorld)
    {
        return plugin.LodestoneMappingStore?.GetAccountName(nameAtWorld);
    }

    private bool IsTellPartnerOnline(string nameAtWorld)
    {
        var accountName = ResolveTellEchoAccountName(nameAtWorld);
        if (string.IsNullOrEmpty(accountName))
        {
            return false;
        }

        return plugin.Services.PresenceService.IsOnline(accountName);
    }

    private string GetTellPartnerPresenceStatus(string nameAtWorld)
    {
        var accountName = ResolveTellEchoAccountName(nameAtWorld);
        if (string.IsNullOrEmpty(accountName))
        {
            return "offline";
        }

        return plugin.Services.PresenceService.GetPresenceStatus(accountName);
    }

    private string TruncateTextWithEllipsis(string text, float maxWidth)
    {
        if (ImGui.CalcTextSize(text).X <= maxWidth)
            return text;

        var ellipsis = "...";
        var ellipsisWidth = ImGui.CalcTextSize(ellipsis).X;
        
        if (ellipsisWidth >= maxWidth)
            return text.Substring(0, Math.Max(1, (int)(maxWidth / ImGui.CalcTextSize("M").X)));

        for (int i = text.Length - 1; i >= 1; i--)
        {
            var truncated = text.Substring(0, i) + ellipsis;
            if (ImGui.CalcTextSize(truncated).X <= maxWidth)
                return truncated;
        }

        return ellipsis;
    }

    private float MeasureRenderedWidth(string text, float emojiSize)
    {
        var matches = EmojiShortcodeRegex.Matches(text);
        if (matches.Count == 0)
            return ImGui.CalcTextSize(text).X;

        float width = 0f;
        int lastIndex = 0;
        foreach (System.Text.RegularExpressions.Match m in matches)
        {
            var emojiName = m.Groups[1].Value;
            var isEmoji = emojiNameToPath.ContainsKey(emojiName) ||
                          bttvCodeToId.ContainsKey(emojiName) ||
                          emojiName.StartsWith("bttv-", StringComparison.OrdinalIgnoreCase);
            if (!isEmoji) continue;

            if (m.Index > lastIndex)
                width += ImGui.CalcTextSize(text.Substring(lastIndex, m.Index - lastIndex)).X;
            width += emojiSize;
            lastIndex = m.Index + m.Length;
        }
        if (lastIndex < text.Length)
            width += ImGui.CalcTextSize(text.Substring(lastIndex)).X;
        return width;
    }

    private string TruncateTextEmojiAware(string text, float maxWidth, float emojiSize)
    {
        if (MeasureRenderedWidth(text, emojiSize) <= maxWidth)
            return text;

        var ellipsis = "...";
        var ellipsisWidth = ImGui.CalcTextSize(ellipsis).X;
        if (ellipsisWidth >= maxWidth)
            return ellipsis;

        // Binary search for the right truncation point
        int lo = 1, hi = text.Length - 1;
        int best = 0;
        while (lo <= hi)
        {
            int mid = (lo + hi) / 2;
            var candidate = text.Substring(0, mid) + ellipsis;
            if (MeasureRenderedWidth(candidate, emojiSize) <= maxWidth)
            {
                best = mid;
                lo = mid + 1;
            }
            else
            {
                hi = mid - 1;
            }
        }

        return best > 0 ? text.Substring(0, best) + ellipsis : ellipsis;
    }

    private string? DrawTellMessage(TellMessage msg, string? lastTimestampTicks)
    {
        var alignmentMode = plugin.Configuration.TellChatAlignment;
        var forceLeft = alignmentMode == ChatAlignmentMode.LeftAligned;
        var isBubbleStyle = alignmentMode == ChatAlignmentMode.BubbleStyle;
        var showTellIcons = alignmentMode != ChatAlignmentMode.SplitSides;
        var showDividerTimestamp = alignmentMode == ChatAlignmentMode.SplitSides;

        var groupingMinutes = Math.Clamp(plugin.Configuration.TimestampGroupingMinutes, 1, 60);
        var showTimestamps = plugin.Configuration.ShowTimestamps;
        string timestamp = string.Empty;
        bool showTimestampDivider = false;
        if (showTimestamps && msg.Timestamp != DateTime.MinValue)
        {
            var localTime = msg.Timestamp.ToLocalTime();
            timestamp = localTime.ToString("HH:mm");

            if (showDividerTimestamp)
            {
                if (string.IsNullOrEmpty(lastTimestampTicks) || !long.TryParse(lastTimestampTicks, out var lastTicks))
                {
                    showTimestampDivider = true;
                }
                else
                {
                    var lastShown = new DateTime(lastTicks, DateTimeKind.Local);
                    var elapsedMinutes = (localTime - lastShown).TotalMinutes;
                    showTimestampDivider = elapsedMinutes >= groupingMinutes;
                }
            }
        }
        var (inIcon, outIcon) = GetTellIconsForStyle(plugin.Configuration.TellIconStyle);
        var senderIcon = msg.IsIncoming ? inIcon : outIcon;
        var messageColor = msg.IsIncoming ? new Vector4(1.0f, 1.0f, 1.0f, 1.0f) : new Vector4(0.7f, 0.7f, 0.7f, 1.0f);

        var bubblePadding = isBubbleStyle ? 8f : 0f;
        var bubbleRounding = isBubbleStyle ? 10f : 0f;
        var bubbleText = msg.Message ?? string.Empty;

        // Avoid duplicate URL line when echo is a GIF URL; we render the preview separately
        if (msg.EchoType == TellEchoType.GifUrl && LooksLikeImageUrl(bubbleText))
        {
            bubbleText = string.Empty;
        }

        var isMine = !msg.IsIncoming;

        if (showTimestampDivider)
        {
            var dividerAvailableWidth = ImGui.GetContentRegionAvail().X;
            var dividerTextSize = ImGui.CalcTextSize(timestamp);
            var startPos = ImGui.GetCursorPos();
            var startScreen = ImGui.GetCursorScreenPos();
            var textOffset = MathF.Max(0f, (dividerAvailableWidth - dividerTextSize.X) * 0.5f);
            var linePadding = 8f;
            var lineY = startScreen.Y + (dividerTextSize.Y * 0.5f);
            var leftLineEndX = startScreen.X + MathF.Max(0f, textOffset - linePadding);
            var rightLineStartX = startScreen.X + textOffset + dividerTextSize.X + linePadding;
            var lineEndX = startScreen.X + dividerAvailableWidth;
            var lineColor = ImGui.GetColorU32(new Vector4(0.35f, 0.35f, 0.4f, 0.6f));

            var drawList = ImGui.GetWindowDrawList();
            if (leftLineEndX > startScreen.X)
            {
                drawList.AddLine(new Vector2(startScreen.X, lineY), new Vector2(leftLineEndX, lineY), lineColor, 1f);
            }
            if (rightLineStartX < lineEndX)
            {
                drawList.AddLine(new Vector2(rightLineStartX, lineY), new Vector2(lineEndX, lineY), lineColor, 1f);
            }

            ImGui.SetCursorPos(new Vector2(startPos.X + textOffset, startPos.Y));
            ImGui.TextDisabled(timestamp);
            ImGui.Spacing();
        }

        var rowStartScreen = ImGui.GetCursorScreenPos();
        var rowWidth = ImGui.GetContentRegionAvail().X;

        var timeSize = (showDividerTimestamp || !showTimestamps || string.IsNullOrEmpty(timestamp))
            ? Vector2.Zero
            : ImGui.CalcTextSize($"[{timestamp}]");
        var iconSize = showTellIcons
            ? ImGui.CalcTextSize(senderIcon).X + ImGui.GetStyle().ItemInnerSpacing.X
            : 0f;
        var availableWidth = ImGui.GetContentRegionAvail().X;
        var maxTextWidth = MathF.Max(50f, availableWidth - timeSize.X - iconSize - (bubblePadding * 2));

        // Measure width/height accounting for rendered emoji size (same logic as DrawMessage in contacts)
        var emojiInfo = GetCachedEmojiInfo(bubbleText);
        var emojiOnly = emojiInfo.EmojiCount > 0 && string.IsNullOrWhiteSpace(emojiInfo.TextWithoutEmojis);
        var emojiSizeForMeasure = emojiOnly ? 48f : ImGui.GetTextLineHeight();
        var baseSize = ImGui.CalcTextSize(emojiInfo.TextWithoutEmojis, false, maxTextWidth);
        var measuredWidth = baseSize.X + emojiInfo.EmojiCount * emojiSizeForMeasure;
        var measuredHeight = Math.Max(baseSize.Y, emojiInfo.EmojiCount > 0 ? emojiSizeForMeasure : baseSize.Y);
        var textSize = new Vector2(Math.Min(measuredWidth, maxTextWidth), measuredHeight);

        // Account for echo-only content (e.g. emoji, attachments, gifs) when computing bubble width/height
        float echoContentWidth = 0f;
        float echoContentHeight = 0f;
        if (msg.IsEchoMessage)
        {
            if (msg.EchoType == TellEchoType.Emoji)
            {
                echoContentWidth = 48f;
                echoContentHeight = 48f;
            }
            else if (msg.EchoType == TellEchoType.Attach || msg.EchoType == TellEchoType.Gif)
            {
                echoContentWidth = 120f;
                echoContentHeight = 90f;
            }
            else if (msg.EchoType == TellEchoType.GifUrl)
            {
                echoContentWidth = 180f;
                echoContentHeight = 130f;
            }
        }

        var baseContentWidth = Math.Min(textSize.X, maxTextWidth);
        var bubbleContentWidth = Math.Max(baseContentWidth, echoContentWidth) + timeSize.X + iconSize;
        var bubbleWidth = bubbleContentWidth + (bubblePadding * 2);

        var bubbleStartX = ImGui.GetCursorPosX();
        if (!msg.IsIncoming && !forceLeft)
        {
            bubbleStartX = ImGui.GetCursorPosX() + Math.Max(0, availableWidth - bubbleWidth);
        }

        var bubbleStartY = ImGui.GetCursorPosY();
        ImGui.SetCursorPos(new Vector2(bubbleStartX, bubbleStartY));
        var bubbleMinScreen = ImGui.GetCursorScreenPos();

        if (isBubbleStyle)
        {
            var drawList = ImGui.GetWindowDrawList();
            var textHeight = Math.Max(Math.Max(textSize.Y, echoContentHeight), ImGui.GetTextLineHeight());
            var bubbleHeight = textHeight + (bubblePadding * 2);

            var bgColor = msg.IsIncoming
                ? ImGui.ColorConvertFloat4ToU32(new Vector4(0.25f, 0.25f, 0.28f, 0.85f))
                : ImGui.ColorConvertFloat4ToU32(new Vector4(0.2f, 0.35f, 0.22f, 0.85f));
            var borderColor = msg.IsIncoming
                ? ImGui.ColorConvertFloat4ToU32(new Vector4(0.4f, 0.4f, 0.45f, 0.9f))
                : ImGui.ColorConvertFloat4ToU32(new Vector4(0.4f, 0.8f, 0.4f, 0.9f));
            var shadowColor = ImGui.ColorConvertFloat4ToU32(new Vector4(0f, 0f, 0f, 0.25f));

            var bubbleMin = bubbleMinScreen;
            var bubbleMax = bubbleMin + new Vector2(bubbleWidth, bubbleHeight);

            if (partyMode.IsActive)
            {
                partyMode.DrawBubbleEffect(bubbleMin, bubbleMax, isMine);
                var partyBg = partyMode.GetBubbleColor(isMine);
                bgColor = ImGui.GetColorU32(partyBg);
            }

            drawList.AddRectFilled(
                bubbleMin + new Vector2(2f, 2f),
                bubbleMax + new Vector2(2f, 2f),
                shadowColor,
                bubbleRounding);

            drawList.AddRectFilled(bubbleMin, bubbleMax, bgColor, bubbleRounding);
            if (!partyMode.IsActive)
            {
                drawList.AddRect(bubbleMin, bubbleMax, borderColor, bubbleRounding, ImDrawFlags.None, 1.5f);
            }

            ImGui.SetCursorPos(new Vector2(bubbleStartX + bubblePadding, bubbleStartY + bubblePadding));
        }

        if (!showDividerTimestamp && showTimestamps && !string.IsNullOrEmpty(timestamp))
        {
            ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(0.6f, 0.6f, 0.6f, 1.0f));
            ImGui.Text($"[{timestamp}]");
            ImGui.PopStyleColor();
            ImGui.SameLine();
        }

        if (showTellIcons)
        {
            ImGui.PushStyleColor(ImGuiCol.Text, new Vector4(0.4f, 0.8f, 0.4f, 1.0f));
            ImGui.PushFont(UiBuilder.IconFont);
            ImGui.Text(senderIcon);
            ImGui.PopFont();
            ImGui.PopStyleColor();
            ImGui.SameLine();
        }

        // Render text body (if any)
        var hasText = !string.IsNullOrWhiteSpace(bubbleText);
        if (hasText)
        {
            ImGui.PushStyleColor(ImGuiCol.Text, messageColor);
            ImGui.PushTextWrapPos(ImGui.GetCursorPosX() + maxTextWidth);
            DrawTextWithUrls(bubbleText, messageColor, maxTextWidth, null, msg.IsIncoming);
            ImGui.PopTextWrapPos();
            ImGui.PopStyleColor();
        }

        // Render Echo attachment/GIF inline
        if (msg.IsEchoMessage)
        {
            var echoColor = new Vector4(0.4f, 0.9f, 0.4f, 0.8f);
            var echoLabelColor = new Vector4(0.4f, 0.9f, 0.4f, 0.6f);

            switch (msg.EchoType)
            {
                case TellEchoType.Attach:
                case TellEchoType.Gif:
                {
                    var attachmentInfo = new ccchat.Data.Models.AttachmentInfo
                    {
                        Id = msg.EchoAttachmentId,
                        Filename = msg.EchoFilename ?? "attachment",
                        Mime = msg.EchoMime ?? "application/octet-stream",
                        Size = msg.EchoSize
                    };

                    var isImage = attachmentInfo.Mime?.StartsWith("image", StringComparison.OrdinalIgnoreCase) == true;
                    var isGif = string.Equals(attachmentInfo.Mime, "image/gif", StringComparison.OrdinalIgnoreCase)
                        || (attachmentInfo.Filename?.EndsWith(".gif", StringComparison.OrdinalIgnoreCase) ?? false);

                    var attachColor = isImage
                        ? new Vector4(0.6f, 0.9f, 1.0f, 1.0f)
                        : new Vector4(0.5f, 0.8f, 0.5f, 1.0f);

                    if (isImage && msg.EchoAttachmentId > 0 && plugin.ChatService.IsLoggedIn && plugin.Configuration.ShowInlineImagePreviews)
                    {
                        if (isGif)
                        {
                            if (!inlineGifCache.ContainsKey(msg.EchoAttachmentId) && !inlineGifLoading.ContainsKey(msg.EchoAttachmentId))
                            {
                                _ = LoadInlineGifFramesAsync(msg.EchoAttachmentId);
                            }

                            if (inlineGifCache.TryGetValue(msg.EchoAttachmentId, out var gifFrames) && gifFrames != null && gifFrames.Count > 0)
                            {
                                UpdateInlineGifAnimation(msg.EchoAttachmentId, gifFrames);
                                var frameIndex = inlineGifFrameIndex.GetValueOrDefault(msg.EchoAttachmentId, 0);
                                frameIndex = Math.Clamp(frameIndex, 0, gifFrames.Count - 1);
                                var frameTexture = gifFrames[frameIndex].Texture;
                                var maxThumbHeight = 80f;
                                var aspect = frameTexture.Height > 0 ? frameTexture.Width / (float)frameTexture.Height : 1f;
                                aspect = MathF.Max(0.1f, aspect);
                                var thumbHeight = maxThumbHeight;
                                var thumbWidth = thumbHeight * aspect;
                                var gifAvailableWidth = Math.Min(maxTextWidth, ImGui.GetContentRegionAvail().X);
                                if (gifAvailableWidth > 0f && thumbWidth > gifAvailableWidth)
                                {
                                    thumbWidth = gifAvailableWidth;
                                    thumbHeight = thumbWidth / aspect;
                                }

                                ImGui.SetCursorPosX(bubbleStartX + bubblePadding);
                                ImGui.PushStyleColor(ImGuiCol.Text, attachColor);
                                ImGui.Text(attachmentInfo.Filename);
                                ImGui.PopStyleColor();

                                ImGui.SetCursorPosX(bubbleStartX + bubblePadding);
                                var thumbPos = ImGui.GetCursorScreenPos();
                                var thumbSize = new Vector2(thumbWidth, thumbHeight);
                                if (ImGui.InvisibleButton($"##tellgif{msg.EchoAttachmentId}", thumbSize))
                                {
                                    plugin.AttachmentWindow.ShowAttachment(attachmentInfo);
                                }
                                ImGui.GetWindowDrawList().AddImageRounded(frameTexture.Handle, thumbPos, thumbPos + thumbSize, Vector2.Zero, Vector2.One, ImGui.GetColorU32(Vector4.One), 6f);

                                if (ImGui.IsItemHovered())
                                {
                                    ImGui.SetTooltip($"Click to view: {attachmentInfo.Filename}");
                                }
                            }
                            else
                            {
                                var maxThumbHeight = 80f;
                                var thumbHeight = maxThumbHeight;
                                var thumbWidth = thumbHeight;
                                var gifAvailableWidth = Math.Min(maxTextWidth, ImGui.GetContentRegionAvail().X);
                                if (gifAvailableWidth > 0f && thumbWidth > gifAvailableWidth)
                                {
                                    thumbWidth = gifAvailableWidth;
                                    thumbHeight = thumbWidth;
                                }

                                ImGui.SetCursorPosX(bubbleStartX + bubblePadding);
                                ImGui.PushStyleColor(ImGuiCol.Text, attachColor);
                                ImGui.Text(attachmentInfo.Filename);
                                ImGui.PopStyleColor();

                                ImGui.SetCursorPosX(bubbleStartX + bubblePadding);
                                var thumbPos = ImGui.GetCursorScreenPos();
                                var thumbSize = new Vector2(thumbWidth, thumbHeight);
                                ImGui.InvisibleButton($"##tellgifloading{msg.EchoAttachmentId}", thumbSize);

                                var drawList = ImGui.GetWindowDrawList();
                                var placeholderColor = ImGui.GetColorU32(new Vector4(0.2f, 0.2f, 0.2f, 0.35f));
                                drawList.AddRectFilled(thumbPos, thumbPos + thumbSize, placeholderColor, 6f);
                                drawList.AddRect(thumbPos, thumbPos + thumbSize, ImGui.GetColorU32(new Vector4(0.5f, 0.5f, 0.5f, 0.6f)), 6f);

                                var spinner = FontAwesomeIcon.Spinner.ToIconString();
                                var spinnerSize = ImGui.CalcTextSize(spinner);
                                var spinnerPos = new Vector2(
                                    thumbPos.X + (thumbSize.X - spinnerSize.X) / 2,
                                    thumbPos.Y + (thumbSize.Y - spinnerSize.Y) / 2
                                );
                                ImGui.PushFont(UiBuilder.IconFont);
                                drawList.AddText(spinnerPos, ImGui.GetColorU32(new Vector4(0.7f, 0.7f, 0.7f, 1.0f)), spinner);
                                ImGui.PopFont();
                            }
                        }
                        else
                        {
                            if (!inlineImageCache.ContainsKey(msg.EchoAttachmentId) && !inlineImageLoading.ContainsKey(msg.EchoAttachmentId))
                            {
                                _ = LoadInlineImageThumbnailAsync(msg.EchoAttachmentId);
                            }

                            if (inlineImageCache.TryGetValue(msg.EchoAttachmentId, out var texture) && texture != null)
                            {
                                var thumbSize = 80f;
                                ImGui.SetCursorPosX(bubbleStartX + bubblePadding);
                                ImGui.PushStyleColor(ImGuiCol.Text, attachColor);
                                ImGui.Text(attachmentInfo.Filename);
                                ImGui.PopStyleColor();

                                ImGui.SetCursorPosX(bubbleStartX + bubblePadding);
                                var thumbPos = ImGui.GetCursorScreenPos();
                                if (ImGui.InvisibleButton($"##tellimg{msg.EchoAttachmentId}", new Vector2(thumbSize, thumbSize)))
                                {
                                    plugin.AttachmentWindow.ShowAttachment(attachmentInfo);
                                }
                                ImGui.GetWindowDrawList().AddImageRounded(texture.Handle, thumbPos, thumbPos + new Vector2(thumbSize, thumbSize), Vector2.Zero, Vector2.One, ImGui.GetColorU32(Vector4.One), 6f);

                                if (ImGui.IsItemHovered())
                                {
                                    ImGui.SetTooltip($"Click to view: {attachmentInfo.Filename}");
                                }
                            }
                            else
                            {
                                var thumbSizeVal = 80f;
                                ImGui.SetCursorPosX(bubbleStartX + bubblePadding);
                                ImGui.PushStyleColor(ImGuiCol.Text, attachColor);
                                ImGui.Text(attachmentInfo.Filename);
                                ImGui.PopStyleColor();

                                ImGui.SetCursorPosX(bubbleStartX + bubblePadding);
                                var thumbPos = ImGui.GetCursorScreenPos();
                                var thumbSize = new Vector2(thumbSizeVal, thumbSizeVal);
                                ImGui.InvisibleButton($"##tellimgloading{msg.EchoAttachmentId}", thumbSize);

                                var drawList = ImGui.GetWindowDrawList();
                                var placeholderColor = ImGui.GetColorU32(new Vector4(0.2f, 0.2f, 0.2f, 0.35f));
                                drawList.AddRectFilled(thumbPos, thumbPos + thumbSize, placeholderColor, 6f);
                                drawList.AddRect(thumbPos, thumbPos + thumbSize, ImGui.GetColorU32(new Vector4(0.5f, 0.5f, 0.5f, 0.6f)), 6f);

                                var spinner = FontAwesomeIcon.Spinner.ToIconString();
                                var spinnerSize = ImGui.CalcTextSize(spinner);
                                var spinnerPos = new Vector2(
                                    thumbPos.X + (thumbSize.X - spinnerSize.X) / 2,
                                    thumbPos.Y + (thumbSize.Y - spinnerSize.Y) / 2
                                );
                                ImGui.PushFont(UiBuilder.IconFont);
                                drawList.AddText(spinnerPos, ImGui.GetColorU32(new Vector4(0.7f, 0.7f, 0.7f, 1.0f)), spinner);
                                ImGui.PopFont();
                            }
                        }
                    }
                    else
                    {
                        var attachIcon = isImage ? FontAwesomeIcon.Image.ToIconString() : FontAwesomeIcon.Paperclip.ToIconString();
                        var attachLabel = isImage
                            ? attachmentInfo.Filename
                            : $"[File: {attachmentInfo.Filename} ({FormatBytes(attachmentInfo.Size)})]";

                        ImGui.PushFont(UiBuilder.IconFont);
                        ImGui.TextColored(attachColor, attachIcon);
                        ImGui.PopFont();
                        ImGui.SameLine(0, ImGui.GetStyle().ItemInnerSpacing.X * 0.75f);
                        ImGui.PushStyleColor(ImGuiCol.Text, attachColor);
                        if (ImGui.Selectable($"{attachLabel}##tellatt{msg.Timestamp.Ticks}", false, ImGuiSelectableFlags.None, new Vector2(Math.Min(maxTextWidth, ImGui.GetContentRegionAvail().X), 0)))
                        {
                            plugin.AttachmentWindow.ShowAttachment(attachmentInfo);
                        }
                        ImGui.PopStyleColor();
                        if (ImGui.IsItemHovered())
                        {
                            ImGui.SetTooltip("Click to view attachment");
                        }
                    }

                    break;
                }
                case TellEchoType.Emoji:
                {
                    var emojiName = msg.EchoData ?? string.Empty;
                    ImGui.PushStyleColor(ImGuiCol.Text, messageColor);
                    ImGui.PushTextWrapPos(ImGui.GetCursorPosX() + maxTextWidth);
                    DrawTextWithUrls($":{emojiName}:", messageColor, maxTextWidth);
                    ImGui.PopTextWrapPos();
                    ImGui.PopStyleColor();
                    break;
                }
                case TellEchoType.GifUrl:
                {
                    var url = msg.EchoData ?? string.Empty;
                    if (string.IsNullOrWhiteSpace(url))
                    {
                        break;
                    }

                    var fallbackDim = new Vector4(0.55f, 0.55f, 0.6f, 1f);

                    if (!inlineGifUrlCache.ContainsKey(url) && !inlineGifUrlLoading.ContainsKey(url))
                    {
                        _ = LoadInlineGifFramesFromUrlAsync(url);
                    }

                    if (inlineGifUrlCache.TryGetValue(url, out var gifFrames) && gifFrames != null && gifFrames.Count > 0)
                    {
                        UpdateInlineGifUrlAnimation(url, gifFrames);
                        var frameIndex = inlineGifUrlFrameIndex.GetValueOrDefault(url, 0);
                        frameIndex = Math.Clamp(frameIndex, 0, gifFrames.Count - 1);
                        var frameTexture = gifFrames[frameIndex].Texture;

                        var maxThumbHeight = 120f;
                        var aspect = frameTexture.Height > 0 ? frameTexture.Width / (float)frameTexture.Height : 1f;
                        aspect = MathF.Max(0.1f, aspect);
                        var thumbHeight = maxThumbHeight;
                        var thumbWidth = thumbHeight * aspect;
                        var availWidth = Math.Min(maxTextWidth, ImGui.GetContentRegionAvail().X);
                        if (availWidth > 0f && thumbWidth > availWidth)
                        {
                            thumbWidth = availWidth;
                            thumbHeight = thumbWidth / aspect;
                        }

                        var gifStartX = bubbleStartX + bubblePadding;
                        if (!msg.IsIncoming && !forceLeft)
                        {
                            var bubbleContentArea = bubbleWidth - (bubblePadding * 2);
                            gifStartX = bubbleStartX + bubblePadding + Math.Max(0, bubbleContentArea - thumbWidth);
                        }

                        ImGui.SetCursorPosX(gifStartX);
                        var thumbPos = ImGui.GetCursorScreenPos();
                        var thumbSize = new Vector2(thumbWidth, thumbHeight);
                        ImGui.InvisibleButton($"##tellgifurl{msg.Timestamp.Ticks}", thumbSize);
                        ImGui.GetWindowDrawList().AddImageRounded(frameTexture.Handle, thumbPos, thumbPos + thumbSize, Vector2.Zero, Vector2.One, ImGui.GetColorU32(Vector4.One), 6f);

                        if (ImGui.IsItemHovered())
                        {
                            ImGui.SetTooltip(url);
                        }
                    }
                    else if (inlineGifUrlLoading.ContainsKey(url))
                    {
                        var maxThumbHeight = 120f;
                        var thumbHeight = maxThumbHeight;
                        var thumbWidth = thumbHeight;
                        var availWidth = Math.Min(maxTextWidth, ImGui.GetContentRegionAvail().X);
                        if (availWidth > 0f && thumbWidth > availWidth)
                        {
                            thumbWidth = availWidth;
                            thumbHeight = thumbWidth;
                        }

                        var gifStartX = bubbleStartX + bubblePadding;
                        if (!msg.IsIncoming && !forceLeft)
                        {
                            var bubbleContentArea = bubbleWidth - (bubblePadding * 2);
                            gifStartX = bubbleStartX + bubblePadding + Math.Max(0, bubbleContentArea - thumbWidth);
                        }

                        ImGui.SetCursorPosX(gifStartX);
                        var thumbPos = ImGui.GetCursorScreenPos();
                        var thumbSize = new Vector2(thumbWidth, thumbHeight);
                        ImGui.InvisibleButton($"##tellgifurl_loading{msg.Timestamp.Ticks}", thumbSize);

                        var drawList = ImGui.GetWindowDrawList();
                        var placeholderColor = ImGui.GetColorU32(new Vector4(0.2f, 0.2f, 0.2f, 0.35f));
                        var borderColor = ImGui.GetColorU32(new Vector4(0.5f, 0.5f, 0.5f, 0.6f));
                        drawList.AddRectFilled(thumbPos, thumbPos + thumbSize, placeholderColor, 6f);
                        drawList.AddRect(thumbPos, thumbPos + thumbSize, borderColor, 6f);

                        var spinner = FontAwesomeIcon.Spinner.ToIconString();
                        var spinnerSize = ImGui.CalcTextSize(spinner);
                        var spinnerPos = new Vector2(
                            thumbPos.X + (thumbSize.X - spinnerSize.X) / 2,
                            thumbPos.Y + (thumbSize.Y - spinnerSize.Y) / 2);
                        ImGui.PushFont(UiBuilder.IconFont);
                        drawList.AddText(spinnerPos, ImGui.GetColorU32(fallbackDim with { W = 1f }), spinner);
                        ImGui.PopFont();
                    }
                    else
                    {
                        ImGui.PushStyleColor(ImGuiCol.Text, fallbackDim);
                        ImGui.Text("(GIF link preview unavailable)");
                        ImGui.PopStyleColor();
                    }

                    break;
                }
            }
        }
        else if (!hasText)
        {
            ImGui.TextDisabled("(empty)");
        }

        var rowEndScreen = ImGui.GetCursorScreenPos();
        var rectMax = new Vector2(rowStartScreen.X + rowWidth, rowEndScreen.Y);
        var popupId = $"TellCopyPopup##{msg.Timestamp.Ticks}";

        if (ImGui.IsMouseHoveringRect(rowStartScreen, rectMax) && ImGui.IsMouseClicked(ImGuiMouseButton.Right))
        {
            ImGui.OpenPopup(popupId);
        }

        if (ImGui.BeginPopup(popupId))
        {
            var copyText = msg.Message ?? string.Empty;
            ImGui.TextDisabled("Copy message");
            var copyHeight = ImGui.GetTextLineHeightWithSpacing() * 4;
            ImGui.InputTextMultiline($"##TellCopyText{msg.Timestamp.Ticks}", ref copyText, MaxMessageLength * 2, new Vector2(Math.Max(250f, rowWidth), copyHeight), ImGuiInputTextFlags.ReadOnly);
            if (ImGui.Button("Copy to clipboard"))
            {
                ImGui.SetClipboardText(copyText);
            }
            ImGui.EndPopup();
        }

        return showTimestampDivider ? msg.Timestamp.ToLocalTime().Ticks.ToString() : lastTimestampTicks;
    }

    private static (string IncomingIcon, string OutgoingIcon) GetTellIconsForStyle(TellIconStyle style)
    {
        return style switch
        {
            TellIconStyle.Arrows => (FontAwesomeIcon.ArrowLeft.ToIconString(), FontAwesomeIcon.ArrowRight.ToIconString()),
            TellIconStyle.EnvelopePlane => (FontAwesomeIcon.Envelope.ToIconString(), FontAwesomeIcon.PaperPlane.ToIconString()),
            TellIconStyle.Comments => (FontAwesomeIcon.Comment.ToIconString(), FontAwesomeIcon.CommentDots.ToIconString()),
            TellIconStyle.UploadDownload => (FontAwesomeIcon.Download.ToIconString(), FontAwesomeIcon.Upload.ToIconString()),
            TellIconStyle.Users => (FontAwesomeIcon.User.ToIconString(), FontAwesomeIcon.UserCircle.ToIconString()),
            TellIconStyle.InboxShare => (FontAwesomeIcon.Inbox.ToIconString(), FontAwesomeIcon.Share.ToIconString()),
            TellIconStyle.Chevrons => (FontAwesomeIcon.ChevronLeft.ToIconString(), FontAwesomeIcon.ChevronRight.ToIconString()),
            TellIconStyle.Carets => (FontAwesomeIcon.CaretLeft.ToIconString(), FontAwesomeIcon.CaretRight.ToIconString()),
            TellIconStyle.SignInOut => (FontAwesomeIcon.SignInAlt.ToIconString(), FontAwesomeIcon.SignOutAlt.ToIconString()),
            TellIconStyle.LongArrows => (FontAwesomeIcon.LongArrowAltLeft.ToIconString(), FontAwesomeIcon.LongArrowAltRight.ToIconString()),
            TellIconStyle.HandPointing => (FontAwesomeIcon.HandPointLeft.ToIconString(), FontAwesomeIcon.HandPointRight.ToIconString()),
            _ => (FontAwesomeIcon.ArrowLeft.ToIconString(), FontAwesomeIcon.ArrowRight.ToIconString())
        };
    }

    private bool DrawToggleSwitch(string id, ref bool value, Vector2 size, Vector4 onColor, Vector4 offColor, Vector4 knobColor)
    {
        // Invisible button for interaction
        var changed = false;
        if (ImGui.InvisibleButton(id, size))
        {
            value = !value;
            changed = true;
        }

        var drawList = ImGui.GetWindowDrawList();
        var pos = ImGui.GetItemRectMin();
        var end = ImGui.GetItemRectMax();

        // Background
        var bgColor = value ? onColor : offColor;
        drawList.AddRectFilled(pos, end, ImGui.GetColorU32(bgColor), size.Y * 0.5f);

        // Knob
        var knobRadius = (size.Y * 0.5f) - 2f;
        var knobX = value ? (end.X - knobRadius - 2f) : (pos.X + knobRadius + 2f);
        var knobCenter = new Vector2(knobX, pos.Y + size.Y * 0.5f);
        drawList.AddCircleFilled(knobCenter, knobRadius, ImGui.GetColorU32(knobColor));

        return changed;
    }

}
